If you want to edit breadcrumb definitions: [CODE](/src/components/dashboard/header/utils.ts)

If you want to access crawl item layout: [CODE](/src/components/crawler/crawl-tables/layout.tsx)

URLS tab types: [CODE](/src/components/crawler/crawl-tables/urls/tabs/index.tsx)

---

# README

```sh
VITE_CRAWLER_WEBSOCKET = wss://socket.crable.co

# VITE_API_URL = https://api-vite.crable.co/api/v1 

# VITE_API_URL = http://localhost:4006/api/v1

# VITE_API_URL = https://xgk3p3cwi8.execute-api.eu-central-1.amazonaws.com/Prod/api/v1

VITE_API_URL = http://localhost:8000/Prod/api/v2

VITE_GOOGLE_REQUEST_URL = "https://accounts.google.com/o/oauth2/auth?response_type=code&client_id=734907222308-qkon4o1ukv47e0dvejreuuc7cdo9k26l.apps.googleusercontent.com&redirect_uri=http://localhost:4004/login/google/callback&scope=openid%20profile%20email&access_type=offline"
```