/* eslint-disable no-undef */
describe("Login process", () => {
  it("successfully opens login page as user isn't authenticated", () => {
    cy.visit("/");
    cy.url().should("include", "/login");
  });
  it("successfully logs in", () => {
    cy.visit("/");
    cy.get('input[name="email"]').type("test@crable.co");
    cy.get('input[name="password"]').type("ThankYouForTesting");
    cy.get('button[type="submit"]').click();
    cy.url().should("include", "/dashboard");
  });
  it("sign in with google", () => {
    cy.visit("/");
    cy.contains("Login with Google").click();
  });
});
