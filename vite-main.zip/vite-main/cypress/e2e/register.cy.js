/* eslint-disable no-undef */
describe("Login process", () => {
  it("successfully opens login page as user isn't authenticated", () => {
    cy.visit("/register");
  });
  it("successfully registers in", () => {
    cy.visit("/register");
    cy.get('input[name="firstName"]').type("E2E");
    cy.get('input[name="lastName"]').type("Test");
    cy.get('input[name="email"]').type("test@crable.co");
    cy.get('input[name="password"]').type("ThankYouForTesting1@");
    cy.get('button[type="submit"]').click();
  });
  it("sign up with google", () => {
    cy.visit("/");
    cy.contains("SignUp with Google").click();
  });
});
