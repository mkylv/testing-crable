const config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      width: {
        sidebar: "256px",
        "sidebar-collapsed": "76px",
      },
      padding: {
        sidebar: "256px",
        "sidebar-collapsed": "76px",
      },
      boxShadow: {
        box: "inset 0 -2px 1px rgba(0,0,0,0.3)",
      },
      backgroundImage: {
        "primary-gradient":
          "linear-gradient(90deg, hsl(var(--primary-from)), hsl(var(--primary-to)))",
        "primary-hover-gradient":
          "linear-gradient(90deg, hsl(var(--primary-hover-from)), hsl(var(--primary-hover-to)))",
      },
      blur: {
        xs: "2px",
      },
      colors: {
        primary: {
          DEFAULT: "hsl(var(--primary-from))",
          foreground: "hsl(var(--primary-foreground))",
        },
        background: {
          DEFAULT: "hsl(var(--background))",
        },
        foreground: "hsl(var(--foreground))",
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        border: {
          primary: "hsl(var(--border-primary))",
          secondary: "hsl(var(--border-secondary))",
        },
        input: "hsl(var(--input))",
        success: {
          DEFAULT: "hsl(var(--success))",
          foreground: "hsl(var(--success-foreground))",
        },
        warning: "hsl(var(--warning))",
        hover: {
          DEFAULT: "hsl(var(--popover) / 20)",
          primary: "hsl(var(--primary-from) / 12)",
        },
        informational: {
          DEFAULT: "hsl(var(--informational))",
        },
        ring: "hsl(var(--primary-from))",
        borderRadius: {
          lg: "var(--radius)",
          md: "calc(var(--radius) - 2px)",
          sm: "calc(var(--radius) - 4px)",
        },
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  // eslint-disable-next-line no-undef
  plugins: [require("tailwindcss-animate")],
};

export default config;
