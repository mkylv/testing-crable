import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { useMemo } from "react";

export default function useCrawlFilters() {
  const {
    selectedIssueBatch,
    setSelectedIssueBatch,
    selectedResponseTime,
    setSelectedResponseTime,
  } = useCrawlerUrlsStore();

  const filters: {
    [key: string]: {
      defaultValue: string;
      exists: boolean;
      get: string;
      set: (f: string) => void;
    };
  } = useMemo(() => {
    return {
      issueBatch: {
        exists: selectedIssueBatch !== "",
        get: selectedIssueBatch,
        set: setSelectedIssueBatch,
        defaultValue: "",
      },
      responseTime: {
        exists: selectedResponseTime !== "all",
        get: selectedResponseTime as string,
        set: setSelectedResponseTime,
        defaultValue: "all",
      },
    };
  }, [
    selectedIssueBatch,
    selectedResponseTime,
    setSelectedIssueBatch,
    setSelectedResponseTime,
  ]);

  const filterExists = Object.values(filters).some((filter) => filter.exists);

  return { filters, filterExists };
}
