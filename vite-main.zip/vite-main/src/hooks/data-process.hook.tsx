import { useEffect } from "react";
import {
  batchAllUrls,
  batchCrawlIssues,
  createIssueBatches,
  unifyCrawlData,
} from "../lib/crawler";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";

const useProcessCrawlData = () => {
  const {
    crawlData,
    setBatchedCrawlData,
    setIssues,
    setRawIssues,
    appendCrawlData: appendToCrawlData,
  } = useCrawlerDataStore();

  useEffect(() => {
    const unifiedData = unifyCrawlData(crawlData);

    const rawIssues = batchCrawlIssues(unifiedData);

    const batchedData = batchAllUrls(unifiedData);
    const issues = createIssueBatches(rawIssues);

    setBatchedCrawlData(batchedData);
    setIssues(issues);
    setRawIssues(rawIssues);
  }, [crawlData, setBatchedCrawlData, setIssues, setRawIssues]);

  const appendCrawlData = (data: any) => {
    const { type, ...rest } = data;

    appendToCrawlData({
      type: "page_detail",
      ...rest,
    });
  };

  return { crawlData, appendCrawlData };
};

export default useProcessCrawlData;
