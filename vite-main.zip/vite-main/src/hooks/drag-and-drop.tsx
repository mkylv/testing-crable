import { ReactNode } from "react";
import { DragDropContext, OnDragEndResponder } from "react-beautiful-dnd";

const useDragDrop = (onDragEnd: OnDragEndResponder) => {
  const Provider = ({ children }: { children: ReactNode }) => (
    <DragDropContext onDragEnd={onDragEnd}>{children}</DragDropContext>
  );

  return { Provider };
};

export default useDragDrop;
