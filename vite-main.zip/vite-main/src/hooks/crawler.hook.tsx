import { UseFormReset } from "react-hook-form";
import { v4 as uuidv4 } from "uuid";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { useCrawlerUtilStore } from "@/stores/crawler/util.store";
import { useToast } from "@/components/ui/use-toast";
import useProcessCrawlData from "./data-process.hook";
import { TCrawler } from "@/components/crawler/crawl-form/utils";

const useCrawler = (resetForm: UseFormReset<TCrawler>) => {
  const { reset: resetCrawlerDataStates } = useCrawlerDataStore();

  const { reset: resetCrawlerUrlsStates } = useCrawlerUrlsStore();

  const { socket, setSocket, status, setStatus } = useCrawlerUtilStore();

  const { appendCrawlData } = useProcessCrawlData();

  const { toast } = useToast();

  const resetStates = () => {
    resetCrawlerDataStates();
    resetCrawlerUrlsStates();
  };

  const resetCrawling = () => {
    resetStates();
    resetForm();
  };

  const startCrawling = (data: TCrawler) => {
    resetCrawlerDataStates();

    const { url: unprocessedUrl, type, js_rendering } = data;

    const url = !/^https?:\/\//i.test(unprocessedUrl)
      ? `https://${unprocessedUrl}`
      : unprocessedUrl;

    const ws = new WebSocket(import.meta.env.VITE_CRAWLER_WEBSOCKET as string);

    setStatus("in-progress");

    setSocket(ws);

    ws.onopen = () => {
      toast({
        title: "Crawling started",
      });
      try {
        Notification.requestPermission();
      } catch (e) {
        () => {};
      }
      ws.send(
        JSON.stringify({
          url,
          type,
          js_rendering,
        })
      );
    };

    ws.onmessage = (responseBuffer: any) => {
      if (responseBuffer.data !== "Done") {
        const wsIncomingResponseBufferData = JSON.parse(responseBuffer.data);

        appendCrawlData({
          id: uuidv4(),
          ...wsIncomingResponseBufferData,
        });
      } else {
        console.log(responseBuffer.data);
        stopCrawl();
      }
    };

    ws.onclose = () => {
      stopCrawl();
    };
  };

  const stopCrawl = () => {
    toast({
      title: "Crawling stopped",
    });
    try {
      Notification.requestPermission().then((perm) => {
        if (perm === "granted") {
          new Notification("Crawling stopped", {
            body: "Crawling has been stopped manually by user or it has been completed.",
          });
        }
      });
    } catch (e) {
      () => {};
    }
    socket?.send("done");
    socket?.close();
    setStatus("done");
  };

  /**
   *
   * There must be a point where socket will be closed and will be continued after `continueCrawl` function triggered
   *
   */
  const pauseCrawl = async () => {
    setStatus("stopping");
    socket?.send("done");
    socket?.close();
    setStatus("paused");
  };

  return {
    resetCrawling,
    startCrawling,
    pauseCrawl,
  };
};

export default useCrawler;
