import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const reorder = (list: any[], startIndex: number, endIndex: number) => {
  const result = Array.from(list);
  const [removed] = result.splice(startIndex, 1);
  result.splice(endIndex, 0, removed);

  return result;
};

export const reorderObject = (
  obj: any,
  startIndex: number,
  endIndex: number
) => {
  const entries = Object.entries(obj);
  const [removed] = entries.splice(startIndex, 1);
  entries.splice(endIndex, 0, removed);

  const result: any = {};

  for (const [key, value] of entries) {
    result[key] = value;
  }

  return result;
};

export const getTextWidth: (text: string, font: "arial") => number = (
  text,
  font
) => {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");

  if (context) {
    context.font = font || getComputedStyle(document.body).font;

    return context.measureText(text).width;
  } else {
    return 0;
  }
};

export const formatDate = (date: Date) => {
  // Check if the date is valid
  if (isNaN(date.getTime())) {
    throw new Error("Invalid date string");
  }

  // Define arrays for month names
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const day = date.getDate();
  const monthIndex = date.getMonth();
  const year = date.getFullYear();

  // Format the date as "Month day, year"
  const formattedDate = `${monthNames[monthIndex]} ${day}, ${year}`;

  return formattedDate;
};

export function convertDomainToProjectName(domain: string) {
  if (domain) {
    // Remove protocol (http, https)
    domain = domain.replace(/^https?:\/\//, "");

    // Remove 'www.' if present
    domain = domain.replace(/^www\./, "");

    // Remove domain extensions
    domain = domain.replace(/\.[a-z]{2,}$/i, "");

    // Split by dots and hyphens
    let parts = domain.split(/[.-]/);

    // Capitalize first letter of each part
    parts = parts.map((part) => part.charAt(0).toUpperCase() + part.slice(1));

    // Join parts to form the project name
    return parts.join(" ");
  } else return "";
}
