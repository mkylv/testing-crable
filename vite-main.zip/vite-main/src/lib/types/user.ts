export type authMethods = "credentials" | "google" | "github";

export interface UserObject extends UserRegister {
  id?: string;
  company?: string;
  createdAt?: Date;
  updatedAt?: Date;
  profilePicture: string;
  isEmailVerified?: boolean;
  method: authMethods;
  phone?: string;
}

export interface UserRegister {
  username: string;
  email?: string;
  password?: string;
  firstName: string;
  lastName: string;
}

export interface EmailVerification {
  id: string;
  key: string;
  user: UserObject;
  expires: Date;
}

export default UserObject;
