export class CrawlFilter {
  // This function is created to intercept filter data for any case
  static filter(
    data: any[],
    settings: {
      key: string;
      value: string;
    }
  ) {
    return data.filter((d) => d[settings.key] === settings.value);
  }
}
