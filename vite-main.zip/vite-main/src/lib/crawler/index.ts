export const batchImages = (crawlData: any[]) => {
  const uniqueUrls = new Set<string>();

  return crawlData
    .filter((data) => data.type === "page_detail" && data.image_detail)
    .flatMap((data) => data.image_detail)
    .filter((detail) => {
      if (!uniqueUrls.has(detail.src)) {
        uniqueUrls.add(detail.src);
        return true;
      }
      return false;
    })
    .map((image) => {
      return {
        type: "image",
        ...image,
      };
    });
};

export const batchExternals = (crawlData: any[]) => {
  const uniqueUrls = new Set<string>();

  return crawlData
    .filter((data) => data.type === "page_detail" && data.external_urls)
    .flatMap((data) => data.external_urls)
    .filter((external) => {
      if (!uniqueUrls.has(external.url)) {
        uniqueUrls.add(external.url);
        return true;
      }
      return false;
    })
    .map((external) => ({
      type: "external",
      ...external,
    }));
};

export const batchCanonicals = (crawlData: any[]) => {
  const uniqueUrls = new Set<string>();

  crawlData.forEach(
    (d) => d.type === "page_detail" && console.log(d.canonical_links)
  );

  return crawlData
    .filter((data) => data.type === "page_detail" && data.canonical_links)
    .flatMap((data) =>
      data.canonical_links.map((url: any) => ({ url, no_index: data.no_index }))
    )
    .filter(({ url }) => {
      if (!uniqueUrls.has(url)) {
        uniqueUrls.add(url);
        return true;
      }
      return false;
    })
    .map((canonical) => ({
      type: "canonical",
      ...canonical,
    }));
};

export const batchResponseTimes = (crawlData: any[]) => {
  const responseTimeData: any[] = [];

  crawlData.forEach((data) => {
    const responseTime = data?.url_detail?.response_time;
    if (responseTime) {
      const ceiled = Math.ceil(responseTime);
      const existing = responseTimeData.find((d) => d.ceil === ceiled);
      if (existing) {
        existing.urls.push(data);
      } else {
        responseTimeData.push({
          ceil: ceiled,
          urls: [data],
        });
      }
    }
  });

  return responseTimeData;
};

export const batchStatics = (crawlData: any[]) => {
  const uniqueUrls = new Set<string>();

  return crawlData
    .filter((data) => data.type === "page_detail" && data.static_urls)
    .flatMap((data) => data.static_urls)
    .filter((static_url) => {
      if (!uniqueUrls.has(static_url.url)) {
        uniqueUrls.add(static_url.url);
        return true;
      }
      return false;
    })
    .map((static_url) => ({
      type: "static",
      ...static_url,
    }));
};

export const batchInternalUrls = (crawlData: any[]) => {
  const uniqueUrls = new Set<string>();

  return crawlData
    .filter((data) => {
      if (!uniqueUrls.has(data.url)) {
        uniqueUrls.add(data.url);
        return true;
      }
      return false;
    })
    .map((data) => ({ ...data }));
};

export const batchAllUrls = (crawlData: any[]) => {
  const uniqueUrls = new Set<string>();

  // Collect all batches
  const _data = [
    ...batchInternalUrls(crawlData),
    ...batchImages(crawlData),
    ...batchCanonicals(crawlData),
    ...batchExternals(crawlData),
    ...batchStatics(crawlData),
  ];

  // Filter unique URLs and collect them
  // const _data = batches.filter((data) => {
  //   if (!uniqueUrls.has(data.url)) {
  //     uniqueUrls.add(data.url);
  //     return true;
  //   }
  //   return false;
  // });

  return _data;
};

export const batchCrawlIssues = (crawlData: any[]) => {
  const _data: any[] = [];

  // ! DATA LEAK
  crawlData.forEach((data) => {
    if (data.type === "page_detail" && data.issues) {
      data.issues.forEach((issue: any) => {
        _data.push(issue);
      });
    }
  });

  return _data;
};

export const unifyCrawlData = (crawlData: any[]) => {
  const unifiedObject: any[] = [];

  crawlData.map((data) => {
    const { type, ...rest } = data;

    if (type === "early_data") {
      if (!unifiedObject.some((d) => d.url === data.url)) {
        unifiedObject.push({
          type: "page_detail",
          ...rest,
        });
      }
    } else if (type === "page_detail") {
      if (unifiedObject.some((d) => d.url === data.url)) {
        const ind = unifiedObject.findIndex((d) => d.url === data.url);

        unifiedObject[ind] = {
          type: "page_detail",
          ...unifiedObject[ind],
          ...rest,
        };
      } else {
        unifiedObject.push({ type: "page_detail", ...rest });
      }
    }
  });

  return unifiedObject;
};

export const createIssueBatches = (issues: any[]) => {
  const uniqueTitles = new Set();
  const batches: any[] = [];

  issues.forEach((data) => {
    const {
      title,
      description,
      priority,
      how_to_fix: howToSolve,
      issue_type,
      element,
    } = data;

    if (!uniqueTitles.has(title)) {
      uniqueTitles.add(title);

      const eligibleIssues = issues.filter((i) => i.title === title);

      batches.push({
        title,
        description,
        howToSolve,
        issue_type,
        priority,
        defaultIssueId: eligibleIssues[0].id,
        issues: eligibleIssues,
        element,
      });
    }
  });

  return batches;
};
