import {
  BugBeetle,
  ClockCounterClockwise,
  Gauge,
  Gear,
  House,
  ListMagnifyingGlass,
  Pulse,
  Sparkle,
  TestTube,
  TreeStructure,
} from "@phosphor-icons/react";
import { ReactNode } from "react";
import { Crab } from "@/assets/crab";
import { cn } from "@/lib/utils";
import { useTheme } from "next-themes";
// import { useTheme } from "next-themes";

export type SidebarLinkType = {
  id: string;
  title: string;
  icon: ReactNode;
  href: string;
  type?: "link";
  withDivider?: boolean;
  locked?: boolean;
};

export const useSidebarLinks = () => {
  const { theme } = useTheme();

  const links: SidebarLinkType[] = [
    {
      id: "home",
      title: "Home",
      icon: <House weight="fill" className="w-5 h-5" />,
      href: "/dashboard",
    },
    {
      id: "crawler",
      title: "Crawler",
      icon: <Crab className={cn("w-5 h-5", theme === "dark" && "invert")} />,
      href: "/dashboard/crawler",
    },
    {
      id: "performance",
      title: "Performance",
      icon: <Gauge className="w-5 h-5" />,
      href: "/dashboard/performance",
      locked: true,
    },
    {
      id: "crawling-history",
      title: "Crawling History",
      icon: <ClockCounterClockwise className="w-5 h-5" />,
      href: "/dashboard/history",
      locked: true,
    },
    {
      id: "core-web-vitals",
      title: "Core Web Vitals",
      icon: <Pulse className="w-5 h-5" />,
      href: "/dashboard/web-vitals",
      withDivider: true,
      locked: true,
    },
    {
      id: "indexing",
      title: "Indexing",
      icon: <ListMagnifyingGlass weight="fill" className="w-5 h-5" />,
      href: "/dashboard/indexing",
      locked: true,
    },
    {
      id: "sitemaps",
      title: "Sitemaps",
      icon: <TreeStructure className="w-5 h-5" />,
      href: "/dashboard/sitemaps",
      locked: true,
    },
    {
      id: "page-experience",
      title: "Page Experience",
      icon: <Sparkle weight="fill" className="w-5 h-5" />,
      href: "/dashboard/page-experience",
      locked: true,
    },
    {
      id: "a-b-testing",
      title: "A/B testing",
      icon: <TestTube weight="fill" className="w-5 h-5" />,
      href: "/dashboard/a-b-testing",
      withDivider: true,
      locked: true,
    },
    {
      id: "settings",
      title: "Settings",
      icon: <Gear weight="fill" className="w-5 h-5" />,
      href: "/dashboard/settings",
    },
  ];

  return { links };
};
