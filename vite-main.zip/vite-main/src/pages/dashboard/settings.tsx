import AccountInformation from "@/components/settings/account-information";
import DeleteAccount from "@/components/settings/delete-account";

export default function SettingsPage() {
  return (
    <div className="flex flex-col gap-12">
      <AccountInformation />
      <div className="flex">
        <DeleteAccount />
      </div>
    </div>
  );
}
