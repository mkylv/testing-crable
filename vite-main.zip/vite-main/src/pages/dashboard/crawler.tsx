import Crawler from "@/components/crawler";

export default function CrawlerPage() {
  return <Crawler />;
}
