import { z } from "zod";

export const settingLimits = {
  numberOfParallelRequests: {
    min: 1,
    max: 30,
  },
  delayBetweenRequests: {
    min: 1,
    max: 100,
  },
  maxNumOfInternalUrls: {
    min: 1,
    max: 100000,
  },
  maxCrawlDurationHours: {
    min: 1,
    max: 168,
  },
  maxDepthLevelFromSeed: {
    min: 1,
    max: 100,
  },
  maxFolderDepthLevel: {
    min: 1,
    max: 100,
  },
  maxUrlLengthChars: {
    min: 1,
    max: 10000,
  },
  maxNumOfQueryParameters: {
    min: 1,
    max: 100,
  },
};

export const CreateProjectSchema = z.object({
  scope: z.enum(["http", "https", "http + https"]),
  url: z
    .string()
    .min(1, "URL is required")
    .refine(
      (url) =>
        /^(?!https?:\/\/)([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/\S*)?$/.test(url),
      {
        message: "Invalid URL format or it contains 'http://' or 'https://'",
      }
    ),
  type: z.enum(["exact", "path", "domain", "subdomains"]),
  name: z.string().min(1, "Project name is required"),

  scheduledCrawls: z.boolean(),
  frequency: z.enum(["daily", "weekly", "monthly"]),
  startDay: z.enum([
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
  ]),
  time: z.string().min(1, "Time is required"),
  timezone: z.string().min(1, "Timezone is required"),
  runFirstCrawlNow: z.boolean(),

  urlSources: z.array(
    z.object({
      name: z.string(),
      title: z.string(),
      inputType: z.enum(["input", "textarea"]).optional(),
      data: z.string().optional(),
      checked: z.boolean(),
      info: z.string(),
      inputPlaceholder: z.string().optional(),
    })
  ),

  numberOfParallelRequests: z
    .number()
    .min(settingLimits.numberOfParallelRequests.min)
    .max(settingLimits.numberOfParallelRequests.max),
  delayBetweenRequests: z
    .number()
    .min(settingLimits.delayBetweenRequests.min)
    .max(settingLimits.delayBetweenRequests.max),

  settings: z.object({
    executeJs: z.boolean(),
    checkImages: z.boolean(),
    checkCss: z.boolean(),
    checkJs: z.boolean(),
    followOnNonCanonical: z.boolean(),
    followNoFollowLinks: z.boolean(),
    checkHttpStatusOfExternals: z.boolean(),
    removeUrlParameters: z.boolean(),
  }),

  limits: z.object({
    maxNumOfInternalUrls: z
      .number()
      .min(settingLimits.maxNumOfInternalUrls.min)
      .max(settingLimits.maxNumOfInternalUrls.max),
    maxCrawlDurationHours: z
      .number()
      .min(settingLimits.maxCrawlDurationHours.min)
      .max(settingLimits.maxCrawlDurationHours.max),
    maxDepthLevelFromSeed: z
      .number()
      .min(settingLimits.maxDepthLevelFromSeed.min)
      .max(settingLimits.maxDepthLevelFromSeed.max),
    maxFolderDepthLevel: z
      .number()
      .min(settingLimits.maxFolderDepthLevel.min)
      .max(settingLimits.maxFolderDepthLevel.max),
    maxUrlLengthChars: z
      .number()
      .min(settingLimits.maxUrlLengthChars.min)
      .max(settingLimits.maxUrlLengthChars.max),
    maxNumOfQueryParameters: z
      .number()
      .min(settingLimits.maxNumOfQueryParameters.min)
      .max(settingLimits.maxNumOfQueryParameters.max),
  }),

  robotsInstructions: z.object({
    ignore: z.boolean(),
    userAgent: z.enum(["mobile", "desktop"]),
  }),

  authentication: z.object({
    httpAuth: z.boolean(),
  }),

  includeUrls: z.array(z.string()),
  excludeUrls: z.array(z.string()),

  rewriteRules: z.object({
    patternToMatch: z.string(),
    replaceWith: z.string(),
  }),
});

export type CreateProjectSchemaType = z.infer<typeof CreateProjectSchema>;