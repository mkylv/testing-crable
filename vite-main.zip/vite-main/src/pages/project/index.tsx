import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ArrowRight } from "@phosphor-icons/react";
import { useMemo, useState } from "react";
import { createProjectSteps } from "./steps";
import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CreateProjectSchema, CreateProjectSchemaType } from "./utils";
import { useNavigate } from "react-router-dom";
import { ProjectDto } from "@/api/project/project.dto";

export default function CreateProjectPage() {
  const navigate = useNavigate();

  const [currentStep, setCurrentStep] = useState(0);

  const methods = useForm({
    resolver: zodResolver(CreateProjectSchema),
    defaultValues: {
      scope: "http + https",
      type: "subdomains",

      scheduledCrawls: true,
      frequency: "weekly",
      startDay: "wednesday",

      time: "12:00",
      timezone: "UTC",
      runFirstCrawlNow: true,

      urlSources: [
        {
          name: "website",
          title: "Website",
          checked: true,
          info: "Crawl the entire website",
        },
        {
          name: "auto-detected-sitemaps",
          title: "Auto-detected sitemaps",
          checked: true,
          info: "Crawl the sitemaps found in the robots.txt file",
        },
        {
          name: "specific-sitemaps",
          title: "Specific sitemaps",
          inputType: "input",
          checked: false,
          info: "Crawl specific sitemaps",
          inputPlaceholder: "Enter sitemap URL",
        },
        {
          name: "custom-url-list",
          title: "Custom URL list",
          inputType: "textarea",
          checked: false,
          info: "Crawl a list of custom URLs",
          inputPlaceholder: "Enter URLs separated by a new line",
        },
        {
          name: "backlinks",
          title: "Backlinks",
          checked: false,
          info: "Crawl the backlinks of the website",
        },
      ],

      numberOfParallelRequests: 1,
      delayBetweenRequests: 2,

      settings: {
        checkImages: true,
        checkCss: true,
        checkJs: true,
        followOnNonCanonical: true,
        followNoFollowLinks: true,
      },

      limits: {
        maxNumOfInternalUrls: 10000,
        maxCrawlDurationHours: 48,
        maxDepthLevelFromSeed: 16,
        maxFolderDepthLevel: 16,
        maxUrlLengthChars: 2048,
        maxNumOfQueryParameters: 12,
      },

      robotsInstructions: {
        userAgent: "desktop",
      },
    },
  });

  const { trigger, handleSubmit } = methods;

  const next = async () => {
    if (currentStep < createProjectSteps.length - 1) {
      const validated = [];

      if (currentStep === 0) {
        const toBeTriggered = ["scope", "url", "type", "name"];

        for (const key of toBeTriggered) {
          // ! To be removed: any
          validated.push(await trigger(key as any));
        }
      }

      if (!validated.includes(false)) setCurrentStep((step) => step + 1);
    }
  };

  const prev = () => {
    if (currentStep > 0) {
      setCurrentStep((step) => step - 1);
    }
  };

  const currentStepObj = useMemo(
    () => createProjectSteps[currentStep],
    [currentStep]
  );

  const submit = (data: any) => console.log(data);

  return (
    <section className="min-h-[90vh] my-12 flex justify-center items-center">
      <FormProvider {...methods}>
        <form onSubmit={handleSubmit(submit)}>
          <Card className="min-w-[500px] max-w-[800px] flex flex-col gap-3">
            <CardHeader>
              <CardTitle className="text-xl">{currentStepObj.title}</CardTitle>
              <CardDescription>{currentStepObj.description}</CardDescription>
            </CardHeader>
            <CardContent>{currentStepObj.component}</CardContent>
            <CardFooter className="flex justify-end gap-4">
              {currentStep === createProjectSteps.length - 1 && (
                <Button
                  type="button"
                  variant={"ghost"}
                  onClick={() => {
                    if (confirm("Are you sure you want to cancel?")) {
                      navigate("/projects");
                    }
                  }}
                >
                  Cancel
                </Button>
              )}
              <Button
                type={currentStep === 0 ? "button" : "submit"}
                onClick={currentStep === 0 ? next : undefined}
                className="flex gap-2 items-center"
              >
                {currentStep !== 0 ? (
                  "Save"
                ) : (
                  <>
                    Continue <ArrowRight />
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </form>
      </FormProvider>
    </section>
  );
}
