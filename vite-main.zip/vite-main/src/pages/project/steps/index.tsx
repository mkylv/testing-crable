import ConfigurationStep from "./configuration";
import ProjectDetailsStep from "./project-details";

export const createProjectSteps = [
  {
    id: "project-details",
    title: "Project Details",
    description: "Set up your website to start analyzing it.",
    component: <ProjectDetailsStep />,
  },
  {
    id: "configuration",
    title: "Schedule Site Audits",
    description: "Set up your website to start analyzing it.",
    component: <ConfigurationStep />,
  },
];
