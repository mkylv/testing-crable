import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn, convertDomainToProjectName } from "@/lib/utils";
import { useEffect } from "react";
import { useFormContext } from "react-hook-form";

export default function ProjectDetailsStep() {
  const {
    control,
    watch,
    setValue,
    formState: { errors },
  } = useFormContext();

  const scope = watch("scope");
  const type = watch("type");
  const url = watch("url");

  const scopes: { [key: string]: string } = {
    http: "http",
    https: "https",
    "http + https": "http + https",
  };

  const urlTypes: { [key: string]: string } = {
    exact: "Exact",
    path: "Path",
    domain: "Domain",
    subdomains: "Subdomains",
  };

  useEffect(() => {
    setTimeout(() => {
      setValue("name", convertDomainToProjectName(url));
    }, 500);
  }, [setValue, url]);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-3 items-center">
        <FormField
          control={control}
          name="scope"
          render={({ field }) => (
            <Select {...field}>
              <SelectTrigger className="h-10 w-min">
                <SelectValue placeholder={scope} />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(scopes).map((type) => (
                  <SelectItem key={type} value={type}>
                    {scopes[type]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        />
        <FormField
          control={control}
          name="url"
          render={({ field }) => (
            <FormItem className="flex flex-col relative w-full">
              <FormControl>
                <Input placeholder="mywebsite.com" {...field} />
              </FormControl>
              <FormMessage className="absolute top-10" />
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="type"
          render={({ field }) => (
            <Select {...field}>
              <SelectTrigger className="h-10 w-min">
                <SelectValue placeholder={urlTypes[type]} />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(urlTypes).map((type) => (
                  <SelectItem key={type} value={type}>
                    {urlTypes[type]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        />
      </div>
      <p className={cn(errors?.url && "mt-5")}>
        Figma ipsum component variant main layer. Community figma share pencil
        link duplicate.
      </p>
      <FormField
        control={control}
        name="name"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Project name</FormLabel>
            <FormControl>
              <Input placeholder="Enter your project name" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </div>
  );
}
