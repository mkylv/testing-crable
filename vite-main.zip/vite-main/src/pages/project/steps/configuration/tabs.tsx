import CrawlSettingsTab from "./crawl-settings";
import ScheduleAuditsTab from "./schedule";
import UrlSourcesTab from "./url-sources";

const tabs = [
  {
    id: "schedule",
    title: "Schedule",
    component: <ScheduleAuditsTab />,
  },
  {
    id: "url-sources",
    title: "URL Sources",
    component: <UrlSourcesTab />,
  },
  {
    id: "crawl-settings",
    title: "Crawl Settings",
    component: <CrawlSettingsTab />,
  },
];

export default tabs;
