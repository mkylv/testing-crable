import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Info } from "@phosphor-icons/react";
import { useFormContext } from "react-hook-form";
import { settingLimits } from "../../utils";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function CrawlSettingsTab() {
  const { control, register, watch } = useFormContext();

  const agent = watch("robotsInstructions.userAgent");

  const settingTypes: { [key: string]: { title: string; info: string } } = {
    executeJs: {
      title: "Execute JavaScript",
      info: "Something informational",
    },
    checkImages: {
      title: "Check Images",
      info: "Something informational",
    },
    checkCss: {
      title: "Check CSS",
      info: "Something informational",
    },
    checkJs: {
      title: "Check JavaScript",
      info: "Something informational",
    },
    followNonCanonical: {
      title: "Follow Non-Canonical",
      info: "Something informational",
    },
    followNoFollowLinks: {
      title: "Follow NoFollow Links",
      info: "Something informational",
    },
    checkHttpStatusOfExternals: {
      title: "Check HTTP Status of External Links",
      info: "Something informational",
    },
    removeUrlParameters: {
      title: "Remove URL Parameters",
      info: "Something informational",
    },
  };

  const limitTypes: {
    [key: string]: { title: string; info: string; indicator: string };
  } = {
    maxNumOfInternalUrls: {
      title: "Max Number of Internal URLs",
      info: "Something informational",
      indicator: "pages",
    },
    maxCrawlDurationHours: {
      title: "Max Crawl Duration Hours",
      info: "Something informational",
      indicator: "hours",
    },
    maxDepthLevelFromSeed: {
      title: "Max Depth Level from Seed",
      info: "Something informational",
      indicator: "clicks",
    },
    maxFolderDepthLevel: {
      title: "Max Folder Depth Level",
      info: "Something informational",
      indicator: "folders",
    },
    maxUrlLengthChars: {
      title: "Max URL Length Characters",
      info: "Something informational",
      indicator: "characters",
    },
    maxNumOfQueryParameters: {
      title: "Max Number of Query Parameters",
      info: "Something informational",
      indicator: "parameters",
    },
  };

  const agentTypes: { [key: string]: string } = {
    desktop: "Desktop",
    mobile: "Mobile",
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Speed Settings */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">Speed Settings</h3>
        <p className="text-secondary-foreground">
          Figma ipsum component variant main layer. Asset undo blur clip plugin
          flatten font.
        </p>
        <div className="flex flex-col gap-3">
          <div className="flex gap-3 items-center">
            <span>Number of parallel requests</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="text-lg" />
                </TooltipTrigger>
                <TooltipContent>Something informational</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <FormField
              control={control}
              name="numberOfParallelRequests"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input type="number" className="max-w-[100px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            From {settingLimits.numberOfParallelRequests.min} to{" "}
            {settingLimits.numberOfParallelRequests.max} requests
          </div>
          <div className="flex gap-3 items-center">
            <span>Delay between requests</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="text-lg" />
                </TooltipTrigger>
                <TooltipContent>Something informational</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <FormField
              control={control}
              name="delayBetweenRequests"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input className="max-w-[100px]" type="number" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            From {settingLimits.delayBetweenRequests.min} to{" "}
            {settingLimits.delayBetweenRequests.max} seconds
          </div>
        </div>
      </div>
      {/* Settings */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">Settings</h3>
        {Object.keys(settingTypes).map((type) => (
          <FormField
            key={type}
            control={control}
            name={`settings.${type}`}
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="flex items-center">
                    <div className="w-[350px] flex gap-2 items-center">
                      <span>{settingTypes[type].title}</span>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="text-lg" />
                          </TooltipTrigger>
                          <TooltipContent>
                            {settingTypes[type].info}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Switch
                      checked={field.value}
                      onCheckedChange={(v) => field.onChange(v)}
                    />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
        ))}
      </div>
      {/* Limits */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">Limits</h3>
        {Object.keys(limitTypes).map((type) => (
          <FormField
            key={type}
            control={control}
            name={`limits.${type}`}
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="flex gap-5 items-center">
                    <div className="w-[270px] flex gap-2 items-center">
                      <span className="text-nowrap">
                        {limitTypes[type].title}
                      </span>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="text-lg" />
                          </TooltipTrigger>
                          <TooltipContent>
                            {limitTypes[type].info}
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <div>
                      <Input type="number" className="w-[200px]" {...field} />
                    </div>
                    <span className="text-nowrap">
                      {/* @ts-expect-error undefined type err */}
                      From {settingLimits[type].min} to{" "}
                      {/* @ts-expect-error undefined type err */}
                      {settingLimits[type].max} {limitTypes[type].indicator}
                    </span>
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
        ))}
      </div>
      {/* Robots Instructions */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">Robots Instructions</h3>
        <div className="flex items-center">
          <div className="w-[220px] flex gap-2 items-center">
            <span>Ignore Robots.txt</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="text-lg" />
                </TooltipTrigger>
                <TooltipContent>Something informational</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <Switch {...register("robotsInstructions.ignore")} />
        </div>
        <div className="flex items-center">
          <div className="w-[220px] flex gap-2 items-center">
            <span>User agent</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="text-lg" />
                </TooltipTrigger>
                <TooltipContent>Something informational</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <FormField
            control={control}
            name="robotsInstructions.userAgent"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <Select
                    value={field.value}
                    onValueChange={(v) => field.onChange(v)}
                  >
                    <SelectTrigger className="h-10 w-min">
                      <SelectValue placeholder={agentTypes[agent]} />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(agentTypes).map((type) => (
                        <SelectItem key={type} value={type}>
                          {agentTypes[type]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>
      {/* Authentication */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">Authentication</h3>
        <p>Set up your website to start analyzing it.</p>
        <div className="flex items-center">
          <div className="w-[220px] flex gap-2 items-center">
            <span>API Key</span>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="text-lg" />
                </TooltipTrigger>
                <TooltipContent>Something informational</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          <div className="flex gap-4 items-center">
            <Switch {...register("authentication.httpAuth")} />
            <span>Upgrade your plan to unlock</span>
          </div>
        </div>
      </div>
      {/* Include & exclude URLs */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">Include and exclude URLs</h3>
        <p>
          Figma ipsum component variant main layer. Edit stroke duplicate
          ellipse flatten scrolling layer device polygon figma. Flatten main
          bullet library figma hand polygon comment.
        </p>
        <FormField
          control={control}
          name="includeUrls"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Include URLs</FormLabel>
              <FormControl>
                <Textarea
                  className="min-h-[150px] bg-background"
                  value={field.value?.join("\n")}
                  onChange={(e) => field.onChange(e.target.value?.split("\n"))}
                  placeholder="One pattern per line"
                />
              </FormControl>
            </FormItem>
          )}
        />
        <FormField
          control={control}
          name="excludeUrls"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Exclude URLs</FormLabel>
              <FormControl>
                <Textarea
                  className="min-h-[150px] bg-background"
                  value={field.value?.join("\n")}
                  onChange={(e) => field.onChange(e.target.value?.split("\n"))}
                  placeholder="One pattern per line"
                />
              </FormControl>
            </FormItem>
          )}
        />
      </div>
      {/*URL rewrite rules
       */}
      <div className="flex flex-col gap-5 p-4 border rounded-lg">
        <h3 className="font-semibold text-xl">URL rewrite rules</h3>
        <p>
          Figma ipsum component variant main layer. Edit stroke duplicate
          ellipse flatten scrolling layer device polygon figma. Flatten main
          bullet library figma hand polygon comment.
        </p>
        <div className="flex gap-4">
          <FormField
            control={control}
            name="rewriteRules.patternToMatch"
            render={({ field }) => (
              <FormItem className="w-full">
                <FormLabel>Pattern to match</FormLabel>
                <FormControl>
                  <Input
                    value={field.value?.join("\n")}
                    onChange={(e) =>
                      field.onChange(e.target.value?.split("\n"))
                    }
                  />
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="rewriteRules.replaceWith"
            render={({ field }) => (
              <FormItem className="w-full">
                <FormLabel>Pattern to replace</FormLabel>
                <FormControl>
                  <Input
                    value={field.value?.join("\n")}
                    onChange={(e) =>
                      field.onChange(e.target.value?.split("\n"))
                    }
                  />
                </FormControl>
              </FormItem>
            )}
          />
        </div>
      </div>
    </div>
  );
}
