import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import tabs from "./tabs";

export default function ConfigurationStep() {
  return (
    <Tabs defaultValue="schedule" className="flex flex-col gap-4">
      <TabsList className="w-full">
        {tabs.map((tab) => (
          <TabsTrigger className="w-full" key={tab.id} value={tab.id}>
            {tab.title}
          </TabsTrigger>
        ))}
      </TabsList>
      {tabs.map((tab) => (
        <TabsContent className="w-full" key={tab.id} value={tab.id}>
          {tab.component}
        </TabsContent>
      ))}
    </Tabs>
  );
}
