import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useFormContext } from "react-hook-form";

export default function ScheduleAuditsTab() {
  const { control, register, watch, setValue } = useFormContext();

  const frequency = watch("frequency");
  const startDay = watch("startDay");

  const frequencyTypes: { [key: string]: string } = {
    daily: "Daily",
    weekly: "Weekly",
    monthly: "Monthly",
  };

  const startDays: { [key: string]: string } = {
    monday: "Monday",
    tuesday: "Tuesday",
    wednesday: "Wednesday",
    thursday: "Thursday",
    friday: "Friday",
    saturday: "Saturday",
    sunday: "Sunday",
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center">
        <span className="w-[220px]">Run Scheduled crawls</span>
        <Switch {...register("scheduledCrawls")} />
      </div>
      <FormField
        control={control}
        name="frequency"
        render={({ field }) => (
          <FormItem>
            <FormLabel className="text-base">Frequency</FormLabel>
            <FormControl>
              <Select
                value={field.value}
                onValueChange={(v) => field.onChange(v)}
              >
                <SelectTrigger className="h-10 w-min">
                  <SelectValue placeholder={frequencyTypes[frequency]} />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(frequencyTypes).map((type) => (
                    <SelectItem key={type} value={type}>
                      {frequencyTypes[type]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={control}
        name="startDay"
        render={() => (
          <FormItem>
            <FormLabel className="text-base">Start day</FormLabel>
            <FormControl>
              <div className="flex">
                {Object.keys(startDays).map((type, i) => (
                  <Button
                    type="button"
                    className={cn(
                      "rounded-none text-xs px-2.5 py-0 h-8",
                      i === 0 && "rounded-l-lg",
                      i === Object.keys(startDays).length - 1 && "rounded-r-lg"
                    )}
                    variant={type === startDay ? "secondary" : "outline"}
                    key={type}
                    onClick={() => setValue("startDay", type)}
                  >
                    {startDays[type].slice(0, 3)}
                  </Button>
                ))}
              </div>
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <hr />
      <div className="flex items-center">
        <span className="w-[220px]">Run first crawl now</span>
        <Switch {...register("runFirstCrawlNow")} />
      </div>
    </div>
  );
}
