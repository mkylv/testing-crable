import { Checkbox } from "@/components/ui/checkbox";
import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Info } from "@phosphor-icons/react";
import { useFormContext } from "react-hook-form";

interface SourceDto {
  name: string;
  title: string;
  inputType?: "input" | "textarea";
  data?: string;
  checked: boolean;
  info: string;
  inputPlaceholder: string;
}

export default function UrlSourcesTab() {
  const { control, register, watch } = useFormContext();

  const urlSources = watch("urlSources");

  return (
    <div className="flex flex-col gap-6">
      <p className="text-lg font-semibold">Choose URL Sources</p>
      {urlSources.map((source: SourceDto, index: number) => (
        <div key={source.name} className="flex flex-col gap-2">
          <FormField
            control={control}
            name={`urlSources.${index}.checked`}
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="flex gap-3 items-center">
                    <Checkbox
                      id={`source-${index}`}
                      checked={field.value}
                      onCheckedChange={(c) => field.onChange(c)}
                    />
                    <label htmlFor={`source-${index}`}>{source.title}</label>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="text-lg" />
                        </TooltipTrigger>
                        <TooltipContent>{source.info}</TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          {source.checked && source.inputType && (
            <>
              {source.inputType === "input" && (
                <Input
                  placeholder={source.inputPlaceholder}
                  {...register(`urlSources.${index}.data`)}
                />
              )}
              {source.inputType === "textarea" && (
                <Textarea
                  className="bg-background"
                  placeholder={source.inputPlaceholder}
                  {...register(`urlSources.${index}.data`)}
                />
              )}
            </>
          )}
        </div>
      ))}
    </div>
  );
}
