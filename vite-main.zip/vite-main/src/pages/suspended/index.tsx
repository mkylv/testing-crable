import { useGetMe } from "@/api/user/hook";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function SuspendedPage() {
  const navigate = useNavigate();

  const { data } = useGetMe();

  useEffect(() => {
    if (data && data.ok) {
      navigate("/dashboard");
    }
  }, [data, navigate]);

  return (
    <section className="flex justify-center items-center min-h-screen">
      Account suspended
    </section>
  );
}
