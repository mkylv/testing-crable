import { TForgotPassword, schema } from "./utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  useProcessForgotPassword,
  useRequestForgotPassword,
} from "@/api/auth/hook";
import { schemaMeets } from "../register/utils";
import { cn } from "@/lib/utils";
import { Check, Circle } from "lucide-react";

const ForgotPasswordPage = () => {
  const navigate = useNavigate();

  const [step, setStep] = useState<number>(1);

  const { toast } = useToast();

  const {
    mutateAsync: requestForgotPassword,
    isPending: isRequestPending,
  } = useRequestForgotPassword();
  const {
    mutateAsync: processForgotPassword,
    isPending: isProcessPending,
  } = useProcessForgotPassword();

  const methods = useForm<TForgotPassword>({
    resolver: zodResolver(schema),
    defaultValues: {
      password: "",
      email: window.sessionStorage.getItem("email") || "",
    },
  });

  const { control, handleSubmit, trigger, watch } = methods;

  const email = watch("email");
  const passwordValue = watch("password");

  useEffect(() => {
    if (typeof window !== "undefined") {
      window.sessionStorage.setItem("email", email);
    }
  }, [email]);

  const sendVerificationCode = async () => {
    if (await trigger("email")) {
      const res = await requestForgotPassword({ email });

      if (!res.ok)
        return toast({
          title: "Error occurred",
          description:
            res.message,
          variant: "destructive",
        });

      toast({
        title: "OTP",
        description:
          "Check your email and enter the confirmation code to change your password",
      });

      setStep(1);
    }
  };

  const submit = async (data: TForgotPassword) => {
    const { email, ...passwordResetData } = data;

    const res = await processForgotPassword({
      otp: passwordResetData.verificationCode,
      password: passwordResetData.password,
      confirmPassword: passwordResetData.confirmPassword,
    });

    if (res.ok)
      toast({
        title: "OTP",
        description:
          "Password reset successfully completed, you will be redirected to login page in 2 seconds",
      });

    setTimeout(() => navigate("/login"), 1500);
  };

  return (
    <Card className="mx-auto w-[350px]">
      <CardHeader>
        <CardTitle className="text-2xl">Forgot password</CardTitle>
        <CardDescription>Enter your email to continue process</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...methods}>
          <form onSubmit={handleSubmit(submit)}>
            <div className="flex flex-col gap-4">
              {step === 0 && (
                <>
                  <div className="flex flex-col gap-2">
                    <FormField
                      control={control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button
                    type="button"
                    onClick={() => sendVerificationCode()}
                    className="w-full"
                    disabled={isRequestPending || isProcessPending}
                  >
                    Next
                  </Button>
                  <Button
                    type="button"
                    onClick={async () => navigate("/login")}
                    className="w-full"
                    disabled={isRequestPending || isProcessPending}
                    variant={"secondary"}
                  >
                    Go back
                  </Button>
                </>
              )}
              {step === 1 && (
                <>
                  <div className="flex flex-col gap-2">
                    <FormField
                      control={control}
                      name="verificationCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Verification code</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter your verification code"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <div className="flex flex-col items-center">
                      <FormField
                        control={control}
                        name="password"
                        render={({ field }) => (
                          <FormItem className="w-full">
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input
                                type="password"
                                placeholder="Enter your password"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                            <FormDescription className="flex flex-col gap-1.5">
                              {schemaMeets.map((item) => (
                                <span
                                  key={item.name}
                                  className={cn(
                                    "flex gap-1 items-center",
                                    item.re.test(passwordValue) &&
                                      "text-success"
                                  )}
                                >
                                  {item.re.test(passwordValue) ? (
                                    <Check size={16} fontWeight={600} />
                                  ) : (
                                    <Circle size={16} fontWeight={600} />
                                  )}
                                  {item.message}
                                </span>
                              ))}
                            </FormDescription>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <FormField
                      control={control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm password</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Confirm your password"
                              type="password"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button
                    type="submit"
                    onClick={() => handleSubmit(submit)}
                    className="w-full"
                    disabled={isRequestPending || isProcessPending}
                  >
                    Finish
                  </Button>
                  <Button
                    type="button"
                    onClick={() => setStep(0)}
                    className="w-full"
                    disabled={isRequestPending || isProcessPending}
                    variant={"secondary"}
                  >
                    Go back
                  </Button>
                </>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default ForgotPasswordPage;
