import { z } from "zod";

export const schema = z
  .object({
    verificationCode: z
      .string()
      .min(1, "Verification code is required")
      .max(6, "Verification code is invalid"),
    email: z.string().min(1, "Email is required").email("Invalid email format"),
    password: z
      .string()
      .min(8, "Password must be at least 8 characters long")
      .refine((val) => /[0-9]/.test(val), {
        message: "Password must include a number",
      })
      .refine((val) => /[a-z]/.test(val), {
        message: "Password must include a lowercase letter",
      })
      .refine((val) => /[A-Z]/.test(val), {
        message: "Password must include an uppercase letter",
      })
      .refine((val) => /[^A-Za-z0-9]/.test(val), {
        message: "Password must include a special symbol",
      }),
    confirmPassword: z.string().min(1, "Password confirmation is required"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export type TForgotPassword = z.infer<typeof schema>;
