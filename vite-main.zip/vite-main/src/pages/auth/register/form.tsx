import { TRegister, schema, schemaMeets } from "./utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button, buttonVariants } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import GoogleIcon from "@/assets/google";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useRegister } from "@/api/auth/hook";
import { Check, Circle, Eye, EyeClosed } from "@phosphor-icons/react";

const RegisterPage = () => {
  const navigate = useNavigate();

  const [seePassword, setSeePassword] = useState(false);

  const { mutateAsync: register } = useRegister();

  const { toast } = useToast();

  const methods = useForm<TRegister>({
    resolver: zodResolver(schema),
    defaultValues: {
      password: "",
    },
  });

  const { control, watch, handleSubmit } = methods;

  const submit = async (data: TRegister) => {
    try {
      const res = await register({
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        password: data.password,
        method: "credentials",
      });

      if (res.ok) navigate("/dashboard");
    } catch (e: any) {
      toast({
        title: "Authentication error",
        description: e.message,
        variant: "destructive",
      });
    }
  };

  const passwordValue = watch("password");

  return (
    <Card className="mx-auto max-w-sm">
      <CardHeader>
        <CardTitle className="text-2xl">Register</CardTitle>
        <CardDescription>
          Enter your information to create an account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...methods}>
          <form onSubmit={handleSubmit(submit)}>
            <div className="flex flex-col gap-4">
              <div className="flex gap-2">
                <FormField
                  control={control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First name</FormLabel>
                      <FormControl>
                        <Input placeholder="First name" {...field} />
                      </FormControl>
                      <FormDescription>
                        This is your public display name.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last name</FormLabel>
                      <FormControl>
                        <Input placeholder="Last name" {...field} />
                      </FormControl>
                      <FormDescription>
                        This is your public display name.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex flex-col gap-2">
                <FormField
                  control={control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your email" {...field} />
                      </FormControl>
                      <FormDescription>
                        This is your login email.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex flex-col gap-2">
                <FormField
                  control={control}
                  name="password"
                  render={({ field }) => (
                    <FormItem className="w-full">
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input
                          type={seePassword ? "text" : "password"}
                          placeholder="Enter your password"
                          endIcon={
                            <button
                              type="button"
                              onClick={() => setSeePassword((s: boolean) => !s)}
                              className="transition-all flex justify-center items-center"
                            >
                              {seePassword ? (
                                <EyeClosed size={18} />
                              ) : (
                                <Eye size={18} />
                              )}
                            </button>
                          }
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                      <FormDescription className="flex flex-col gap-1.5">
                        {schemaMeets.map((item) => (
                          <span
                            key={item.name}
                            className={cn(
                              "flex gap-1 items-center",
                              item.re.test(passwordValue) && "text-success"
                            )}
                          >
                            {item.re.test(passwordValue) ? (
                              <Check size={16} fontWeight={600} />
                            ) : (
                              <Circle size={16} fontWeight={600} />
                            )}
                            {item.message}
                          </span>
                        ))}
                      </FormDescription>
                    </FormItem>
                  )}
                />
              </div>
              <Button type="submit" className="w-full">
                Sign up
              </Button>
              {/* <Link
                href="/api/auth/oauth?provider=github"
                className={cn(
                  "w-full",
                  buttonVariants({ variant: "outline" }),
                  "hover:bg-popover"
                )}
              >
                <div className="flex gap-2 items-center">
                  {theme === "dark" ? <GithubDark /> : <GithubLight />}
                  Login with Github
                </div>
              </Link> */}
              <Link
                to={`${import.meta.env.VITE_API_URL}/oauth-service/google`}
                className={cn("w-full", buttonVariants({ variant: "outline" }))}
              >
                <div className="flex gap-2 items-center">
                  <GoogleIcon />
                  Sign up with Google
                </div>
              </Link>
            </div>
            <div className="mt-4 text-center text-sm">
              Already have an account?{" "}
              <Link to="/login" className="text-accent">
                Sign in
              </Link>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default RegisterPage;
