import { z } from "zod";

export const schemaMeets = [
  {
    name: "includesNumber",
    re: /[0-9]/,
    message: "Number (0-9)",
  },
  {
    name: "includesLowercase",
    re: /[a-z]/,
    message: "Lowercase letter (a-z)",
  },
  {
    name: "includesUppercase",
    re: /[A-Z]/,
    message: "Uppercase letter (A-Z)",
  },
  {
    name: "includesSpecial",
    re: /[^A-Za-z0-9]/,
    message: "Special symbols like $, %,^, &",
  },
];

export const schema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().min(1, "Email is required").email("Invalid email format"),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters long")
    .refine((val) => /[0-9]/.test(val), {
      message: "Password must include a number",
    })
    .refine((val) => /[a-z]/.test(val), {
      message: "Password must include a lowercase letter",
    })
    .refine((val) => /[A-Z]/.test(val), {
      message: "Password must include an uppercase letter",
    })
    .refine((val) => /[^A-Za-z0-9]/.test(val), {
      message: "Password must include a special symbol",
    }),
});

export type TRegister = z.infer<typeof schema>;
