import { TLogin, schema } from "./utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button, buttonVariants } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { Separator } from "@/components/ui/separator";
import GoogleIcon from "@/assets/google";
import { useLogin } from "@/api/auth/hook";
import { useState } from "react";
import { Eye, EyeClosed } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";

const LoginPage = () => {
  const navigate = useNavigate();

  const [seePassword, setSeePassword] = useState(false);

  const { mutateAsync: login } = useLogin();

  const { toast } = useToast();

  const methods = useForm<TLogin>({
    resolver: zodResolver(schema),
  });

  const { control, handleSubmit } = methods;

  const submit = async (data: TLogin) => {
    try {
      const res = await login(data);

      if (res.ok) navigate("/dashboard");
    } catch (e: any) {
      toast({
        title: "Authentication error",
        description: e.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="mx-auto max-w-sm">
      <CardHeader>
        <CardTitle className="text-2xl">Login</CardTitle>
        <CardDescription>
          Enter your email below to login to your account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...methods}>
          <form onSubmit={handleSubmit(submit)}>
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-2">
                <FormField
                  control={control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input
                          defaultValue={""}
                          placeholder="Enter your email"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex flex-col gap-2">
                <div className="flex items-center">
                  <FormField
                    control={control}
                    name="password"
                    render={({ field }) => (
                      <FormItem className="w-full">
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input
                            type={seePassword ? "text" : "password"}
                            placeholder="Enter your password"
                            endIcon={
                              <button
                                type="button"
                                id="passwordVisibilityManager"
                                onClick={() =>
                                  setSeePassword((s: boolean) => !s)
                                }
                                className="transition-all flex justify-center items-center"
                              >
                                {seePassword ? (
                                  <EyeClosed size={18} />
                                ) : (
                                  <Eye size={18} />
                                )}
                              </button>
                            }
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="flex justify-end">
                  <Link to="/forgot-password" className="text-sm">
                    Forgot password?
                  </Link>
                </div>
              </div>
              <Button type="submit" className="w-full">
                Login
              </Button>
              <div className="flex gap-2 text-muted-foreground justify-center items-center">
                <Separator orientation="horizontal" className="max-w-[125px]" />
                <span>Or</span>
                <Separator orientation="horizontal" className="max-w-[125px]" />
              </div>
              {/* <Link
                to={`${import.meta.env.API_URL}/auth-service/oauth/google`}
                className={cn("w-full", buttonVariants({ variant: "outline" }))}
              >
            
              </Link> */}
              <Link
                to={`${import.meta.env.VITE_API_URL}/oauth-service/google`}
                className={cn("w-full", buttonVariants({ variant: "outline" }))}
              >
                <div className="flex gap-2 items-center">
                  <GoogleIcon />
                  Login with Google
                </div>
              </Link>
            </div>
            <div className="mt-4 text-center text-sm">
              Don&apos;t have an account?{" "}
              <Link to="/register" className="text-accent">
                Sign up
              </Link>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default LoginPage;
