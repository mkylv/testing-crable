import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

export default function GoogleAuthCallbackPage() {
  const [URLSearchParams] = useSearchParams();

  // const { mutateAsync: sendGoogleToken } = useSendGoogleToken();

  useEffect(() => {
    (async () => {
      if (URLSearchParams.get("code")) {
        // await sendGoogleToken(URLSearchParams.get("code") || "");

        setTimeout(() => (window.location.href = "/dashboard"), 1000);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [URLSearchParams]);

  return <></>;
}
