import axios from "axios";

const meInterceptor = axios.create({
  withCredentials: true,
  baseURL: `${import.meta.env.VITE_API_URL}/user-service`,
});

export default meInterceptor;
