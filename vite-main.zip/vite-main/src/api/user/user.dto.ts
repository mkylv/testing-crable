import { RegisterDto } from "../auth/auth.dto";

export interface UserUpdateDto {
  username?: string;
  firstName?: string;
  lastName?: string;
  company?: string;
  profilePicture?: string;
}

export interface UserDto extends RegisterDto {
  id: string;
  company: string;
  profilePicture: string;
  isEmailVerified: boolean;
  suspended: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserVerifyDto {
  otp: string;
}

export interface UserVerifyRequestDto {
  email: string;
}

export interface UserChangeEmailRequestDto extends UserVerifyRequestDto {}
