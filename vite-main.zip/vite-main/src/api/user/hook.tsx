import { useMutation, useQuery } from "@tanstack/react-query";
import meInterceptor from "./interceptor";
import { UserVerifyDto } from "@/api/user/user.dto";
import {
  UserChangeEmailRequestDto,
  UserUpdateDto,
  UserVerifyRequestDto,
} from "@/api/user/user.dto";

export function useGetMe() {
  return useQuery({
    queryKey: ["user"],
    queryFn: async () => {
      try {
        const { data } = await meInterceptor.get("/me");

        return data;
      } catch (e: any) {
        if (e.request.status === 403)
          return {
            ok: false,
            message: "Forbidden",
            code: 403,
          };

        return {
          ok: false,
          message: e.message,
        };
      }
    },
    refetchOnWindowFocus: false,
  });
}

export function useUpdateMe() {
  return useMutation({
    mutationFn: async (data: UserUpdateDto) => {
      const { data: res } = await meInterceptor.put("/me", data, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      return res;
    },
  });
}

export function useSuspendAccount() {
  return useMutation({
    mutationFn: async () => {
      const { data } = await meInterceptor.post("/suspend");
      return data;
    },
  });
}

export function useUnsuspendAccount() {
  return useMutation({
    mutationFn: async () => {
      const { data } = await meInterceptor.post("/unsuspend");
      return data;
    },
  });
}

export function useVerifyAccount() {
  return useMutation({
    mutationFn: async (requestData: UserVerifyDto) => {
      const { data } = await meInterceptor.post("/verify", requestData);
      return data;
    },
  });
}

export function useResendAccountVerification() {
  return useMutation({
    mutationFn: async (requestData: UserVerifyRequestDto) => {
      const { data } = await meInterceptor.post(
        "/resend-verification",
        requestData
      );
      return data;
    },
  });
}

export function useChangeEmail() {
  return useMutation({
    mutationFn: async (requestData: UserChangeEmailRequestDto) => {
      const { data } = await meInterceptor.post(`/change-email`, requestData);
      return data;
    },
  });
}
