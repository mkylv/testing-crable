import axios from "axios";

const defaultConfig = {
  baseURL: `${import.meta.env.VITE_API_URL}/auth-service`,
};

const authInterceptor = axios.create({
  withCredentials: true, 
  ...defaultConfig,
});

export const freeAuthInterceptor = axios.create(defaultConfig);

export default authInterceptor;
