import { useMutation } from "@tanstack/react-query";
import authInterceptor from "./interceptor";
import {
  ChangePasswordDto,
  ForgotPasswordProcessDto,
  ForgotPasswordRequestDto,
  LoginDto,
  RegisterDto,
} from "@/api/auth/auth.dto";

export function useLogin() {
  return useMutation({
    mutationFn: async (requestData: LoginDto) => {
      const { data } = await authInterceptor.post("/login", requestData);
      return data;
    },
  });
}

export function useRegister() {
  return useMutation({
    mutationFn: async (requestData: RegisterDto) => {
      const { data } = await authInterceptor.post("/register", requestData);
      return data;
    },
  });
}

export function useLogout() {
  return useMutation({
    mutationFn: async () => {
      const { data } = await authInterceptor.post("/logout");
      return data;
    },
  });
}

export function useRequestForgotPassword() {
  return useMutation({
    mutationFn: async (requestData: ForgotPasswordRequestDto) => {
      const { data } = await authInterceptor.post(
        `/forgot-password`,
        requestData
      );
      return data;
    },
  });
}

export function useProcessForgotPassword() {
  return useMutation({
    mutationFn: async (requestData: ForgotPasswordProcessDto) => {
      const { data } = await authInterceptor.post(
        `/forgot-password`,
        requestData
      );
      return data;
    },
  });
}

// ! DEPRECATED
export function useChangePassword() {
  return useMutation({
    mutationFn: async (requestData: ChangePasswordDto) => {
      const { data } = await authInterceptor.post(
        `/change-password`,
        requestData
      );
      return data;
    },
  });
}
