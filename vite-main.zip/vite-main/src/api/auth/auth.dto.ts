import { UserVerifyRequestDto } from "../user/user.dto";

export type AuthMethods = "credentials" | "google" | "github";

export interface LoginDto {
  email: string;
  password: string;
}

export interface RegisterDto {
  email: string;
  username?: string;
  password: string;
  method: AuthMethods;
  firstName: string;
  lastName: string;
}

export interface UserVerifyDto {
  otp_key: string;
}

export interface ForgotPasswordRequestDto extends UserVerifyRequestDto {}

export interface ForgotPasswordProcessDto {
  otp: string;
  password: string;
  confirmPassword: string;
}

export interface ChangePasswordDto {
  oldPassword: "string";
  newPassword: "string";
  confirmNewPassword: "string";
}
