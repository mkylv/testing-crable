import { useMutation, useQuery } from "@tanstack/react-query";
import projectInterceptor from "./interceptor";
import { ProjectDto } from "@/api/project/project.dto";

export function useCreateProject() {
  return useMutation({
    mutationFn: async (requestData: ProjectDto) => {
      const { data } = await projectInterceptor.post(`/create`, requestData);
      return data;
    },
  });
}

export function useGetProjects() {
  return useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data } = await projectInterceptor.get(`/list`);
      return data;
    },
  });
}

export function useGetProject() {
  return useMutation({
    mutationFn: async (requestData: { projectId: string }) => {
      const { data } = await projectInterceptor.get(
        `/detail/${requestData.projectId}`
      );
      return data;
    },
  });
}

export function useUpdateProject() {
  return useMutation({
    mutationFn: async (requestData: {
      projectId: string;
      data: Partial<ProjectDto>;
    }) => {
      const { data } = await projectInterceptor.put(
        `/detail/${requestData.projectId}`,
        requestData.data
      );
      return data;
    },
  });
}

export function useDeleteProject() {
  return useMutation({
    mutationFn: async (requestData: { projectId: string }) => {
      const { data } = await projectInterceptor.delete(
        `/detail/${requestData.projectId}`
      );
      return data;
    },
  });
}
