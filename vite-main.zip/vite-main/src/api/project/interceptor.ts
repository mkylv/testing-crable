import axios from "axios";

const projectInterceptor = axios.create({
  withCredentials: true,
  baseURL: `${import.meta.env.VITE_API_URL}/project-service`,
});

export default projectInterceptor;
