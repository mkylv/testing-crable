export interface ProjectOptionalFieldsDto {
  scope?: string;
  type?: string;
  scheduledCrawls?: boolean;
  frequency?: string;
  startDay?: string;
  time?: string;
  timezone?: string;
  websiteAsSource?: boolean;
  autoDetectedSitemapsAsSource?: boolean;
  specificSitemapAsSource?: boolean;
  specificSitemapUrlsAsSource?: string[];
  customUrlSourceAsSource?: boolean;
  customUrlListAsSource?: string[];
  backlinksAsSource?: boolean;
  numberOfParallelRequests?: number;
  delayBetweenRequests?: number;
  executeJsAsSetting?: boolean;
  checkImagesAsSetting?: boolean;
  checkCssAsSetting?: boolean;
  checkJsAsSetting?: boolean;
  followCanonicalLinksAsSetting?: boolean;
  followNofollowLinksAsSetting?: boolean;
  checkHttpStatusOfExternalsAsSetting?: boolean;
  removeUrlParametersAsSetting?: boolean;
  maxNumOfInternalUrls?: number;
  maxCrawlDurationHours?: number;
  maxDepthLevelFromSeed?: number;
  maxFolderDepthLevel?: number;
  maxUrlLengthChars?: number;
  maxNumOfQueryParameters?: number;
  ignoreRobotsInstructions?: boolean;
  robotsInstructionsUserAgent?: string;
  httpAuth?: boolean;
  includeUrls?: string[];
  excludeUrls?: string[];
  rewritePatternToMatch?: string;
  rewritePatternToReplaceWith?: string;
}

export interface ProjectDto extends ProjectOptionalFieldsDto {
  url: string;
  name: string;
}
