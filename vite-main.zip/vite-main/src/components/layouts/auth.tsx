import Cookies from "js-cookie";
import { Navigate, Outlet, useLocation, useNavigate } from "react-router-dom";
import ConfirmEmailModal from "../auth/confirm-account/modal";
import { useGetMe } from "@/api/user/hook";
import { useEffect } from "react";
import { useUserStore } from "@/stores/user.store";
import Loading from "../common/loading";

export function WithAuth() {
  const navigate = useNavigate();

  const { data, isPending } = useGetMe();
  const { user, setUser } = useUserStore();

  const isLoggedIn = eval(Cookies.get("isLoggedIn") || "false");

  useEffect(() => {
    if (data && !data.ok && data.code === 403) {
      navigate("suspended");
    }
    if (data && data.ok) {
      if (data && data.data) setUser(data.data);
    }
  }, [data, navigate, setUser]);

  if (!isLoggedIn) return <Navigate to="/login" />;

  if (isPending || !user) return <Loading />;

  return user ? <Outlet /> : <Navigate to="/login" />;
}

export function WithVerification() {
  const { user } = useUserStore();

  return user?.isEmailVerified ? <Outlet /> : <ConfirmEmailModal />;
}

export function NoAuthRequired() {
  const { pathname } = useLocation();

  const isLoggedIn = eval(Cookies.get("isLoggedIn") || "false");

  const authUrls = [
    "/login",
    "/login/google/callback",
    "/register",
    "/forgot-password",
  ];

  return isLoggedIn ? (
    <Navigate to="/dashboard" />
  ) : authUrls.includes(pathname) ? (
    <div className="h-screen flex justify-center items-center">
      <Outlet />
    </div>
  ) : (
    <Navigate to="/login" />
  );
}
