import { Outlet } from "react-router-dom";
import { Header, Sidebar } from "../dashboard";
import { DashboardContainer } from "../dashboard/dashboard-container";
import { ThemeToggle } from "../common/theme-toggle";

export default function DashboardLayout() {
  return (
    <main className="flex min-h-full flex-col">
      <Sidebar />
      <DashboardContainer>
        <Header />
        <section className="p-10">
          <Outlet />
        </section>
      </DashboardContainer>
      <ThemeToggle />
    </main>
  );
}
