import { useForm } from "react-hook-form";
import { TAccountInformation, schema } from "./utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import { useUserStore } from "@/stores/user.store";
import { useChangeEmail, useUpdateMe } from "@/api/user/hook";

const AccountInformationForm = () => {
  const { mutateAsync: updateMe, isPending: isUpdatePending } = useUpdateMe();
  const { mutateAsync: changeEmail, isPending: isEmailChangePending } =
    useChangeEmail();

  const { user } = useUserStore();

  const methods = useForm<TAccountInformation>({
    resolver: zodResolver(schema),
    defaultValues: {
      ...(user && {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email || "",
        company: user.company || "",
      }),
    },
  });

  const { toast } = useToast();

  const {
    formState: { isDirty, dirtyFields },
    control,
    handleSubmit,
    reset,
  } = methods;

  const submit = async (data: TAccountInformation) => {
    if (isDirty) {
      const { email, ...rest } = data;

      if (dirtyFields?.email) {
        try {
          const res = await changeEmail({ email: email || "" });

          if (res.ok) {
            reset({
              email: data.email || "",
            });

            return toast({
              title: "Email change request sent",
              description: "Please, verify your email to complete the process",
            });
          }
        } catch (e: any) {
          return toast({
            title: "Error occurred",
            description: e.message,
            variant: "destructive",
          });
        }
      }

      if (
        dirtyFields?.company ||
        dirtyFields?.firstName ||
        dirtyFields?.lastName
      ) {
        try {
          const res = await updateMe(rest);

          if (res.ok) {
            reset({
              firstName: data.firstName,
              lastName: data.lastName,
              company: data.company || "",
            });

            return toast({
              title: "Account information updated",
              description: "Account information updated successfully",
            });
          }
        } catch (e: any) {
          return toast({
            title: "Error occurred",
            description: e.message,
            variant: "destructive",
          });
        }
      }
    }
  };

  if(!user) return null;

  return (
    <Form {...methods}>
      <form onSubmit={handleSubmit(submit)} className="flex flex-col gap-5">
        <div className="flex flex-col gap-5 p-3">
          <div className="flex gap-4">
            <FormField
              control={control}
              name="firstName"
              render={({ field }) => (
                <FormItem className="w-full">
                  <FormLabel>First name</FormLabel>
                  <FormControl>
                    <Input placeholder="First name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={control}
              name="lastName"
              render={({ field }) => (
                <FormItem className="w-full">
                  <FormLabel>Last name</FormLabel>
                  <FormControl>
                    <Input placeholder="Last name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <FormField
            control={control}
            name="email"
            render={({ field }) => (
              <FormItem className="w-full">
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input
                    className={cn(
                      user.email &&
                        !user.isEmailVerified &&
                        "border-destructive"
                    )}
                    placeholder="Email"
                    {...field}
                  />
                </FormControl>
                <FormMessage>
                  {user.email && !user.isEmailVerified && (
                    <span className="text-destructive">
                      Email is not verified
                    </span>
                  )}
                </FormMessage>
              </FormItem>
            )}
          />
          <FormField
            control={control}
            name="company"
            render={({ field }) => (
              <FormItem className="w-full">
                <FormLabel>Company</FormLabel>
                <FormControl>
                  <Input placeholder="Company" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <hr />
        <div className="flex gap-3">
          <Button
            type="submit"
            disabled={isUpdatePending || isEmailChangePending}
          >
            Save
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default AccountInformationForm;
