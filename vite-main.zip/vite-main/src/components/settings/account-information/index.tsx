import AccountInformationForm from "./form";

export default function AccountInformation() {
  return (
    <section className="flex flex-col gap-5 p-6 border rounded-lg">
      <div className="flex flex-col gap-1">
        <h1 className="text-xl font-semibold">Account Information</h1>
        <span className="text-sm text-gray-500">Your account details.</span>
      </div>
      <AccountInformationForm />
    </section>
  );
}
