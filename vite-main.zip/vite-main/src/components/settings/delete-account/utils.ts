import { z } from "zod";

export const schema = z
  .object({
    confirmationText: z.string().min(1),
  })
  .refine((data) => data.confirmationText === "delete my account permanently", {
    message: "Input is incorrect",
    path: ["confirmationText"],
  });

export type TDeleteAccount = z.infer<typeof schema>;
