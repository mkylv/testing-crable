import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormField,
  FormItem,
  FormControl,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { TDeleteAccount, schema } from "./utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useSuspendAccount } from "@/api/user/hook";

const DeleteAccount = () => {
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);

  const { toast } = useToast();

  const { mutateAsync: suspendAccount } = useSuspendAccount();

  const methods = useForm<TDeleteAccount>({
    resolver: zodResolver(schema),
  });

  const { watch, control, handleSubmit } = methods;

  const submit = async () => {
    try {
      const res = await suspendAccount();

      if (!res.err) navigate("/");
    } catch (e: any) {
      toast({
        title: "Error occurred while deleting account",
        description: e.message,
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <section className="flex flex-col gap-5 p-6 border rounded-lg">
        <div className="text-sm flex flex-col gap-1">
          <h1 className="text-red-500">Delete Account</h1>
          <span className=" text-gray-500">
            The following actions are destructive and cannot be reversed.
          </span>
        </div>
        <hr />
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger>
            <div className="flex justify-start">
              <Button
                variant={"outline"}
                className="border-destructive text-destructive hover:bg-destructive hover:text-white"
              >
                Delete
              </Button>
            </div>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Are you absolutely sure?</DialogTitle>
              <DialogDescription>
                This action cannot be undone. This will permanently delete your
                account and remove your data from our servers.
              </DialogDescription>
            </DialogHeader>
            <Form {...methods}>
              <form onSubmit={handleSubmit(submit)}>
                <FormField
                  control={control}
                  name="confirmationText"
                  render={({ field }) => (
                    <FormItem className="py-4">
                      <FormControl>
                        <Input
                          placeholder="delete my account permanently"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        In order to delete your account, type{" "}
                        <span className="text-destructive">
                          delete my account permanently
                        </span>{" "}
                        and submit.
                      </FormDescription>
                      <FormMessage className="absolute" />
                    </FormItem>
                  )}
                />
                <Button
                  variant="destructive"
                  type="submit"
                  disabled={
                    watch("confirmationText") !==
                    "delete my account permanently"
                  }
                >
                  Delete
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </section>
    </>
  );
};

export default DeleteAccount;
