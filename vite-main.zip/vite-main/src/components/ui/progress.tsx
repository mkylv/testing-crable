import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";

import { cn } from "@/lib/utils";

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root> & {
    indicatorClassName?: string;
  } & { includeText?: boolean }
>(({ includeText, className, indicatorClassName, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn(
      "relative h-2 w-full overflow-hidden rounded-full bg-primary/20",
      className
    )}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className={cn(
        "h-full w-full flex-1 bg-primary transition-all",
        indicatorClassName && indicatorClassName
      )}
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
    {includeText && <>{value}%</>}
  </ProgressPrimitive.Root>
));
Progress.displayName = ProgressPrimitive.Root.displayName;

export const CustomProgress = ({ value }: { value: number }) => {
  return (
    <div className="w-full bg-gray-200 rounded-full dark:bg-gray-700">
      <div
        className="bg-accent text-xs font-medium text-blue-100 text-center px-0.5 py-1.5 leading-none rounded-full"
        style={{
          width: `${value}%`,
        }}
      >
        {value}%
      </div>
    </div>
  );
};

export const CustomProgressProcessing = () => {
  return (
    <div className="animate-pulse w-full bg-gray-200 rounded-full overflow-hidden relative h-4">
      <div className="h-full bg-accent bg-repeat-round bg-gradient-to-r from-accent to-accent via-transparent animate-dash"></div>
    </div>
  );
};

export const CustomRadialProgress = ({ value }: { value: number }) => {
  return (
    <div className="shrink-0 relative size-11">
      <svg
        className="size-full"
        width="36"
        height="36"
        viewBox="0 0 36 36"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="18"
          cy="18"
          r="16"
          fill="none"
          className="stroke-current text-gray-200 dark:text-neutral-700"
          stroke-width="4"
        ></circle>
        <g className="origin-center -rotate-90 transform">
          <circle
            cx="18"
            cy="18"
            r="16"
            fill="none"
            className="stroke-current text-primary"
            stroke-width="4"
            stroke-dasharray="100"
            stroke-dashoffset={100 - value}
          ></circle>
        </g>
      </svg>
      <div className="absolute top-1/2 start-1/2 transform -translate-y-1/2 -translate-x-1/2">
        <span className="text-center text-xs text-foreground">{value}%</span>
      </div>
    </div>
  );
};

export const CustomRadialProgressProcessing = () => {
  return (
    <div className="shrink-0 relative size-11">
      <svg
        className="size-full animate-spin"
        width="36"
        height="36"
        viewBox="0 0 36 36"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle
          cx="18"
          cy="18"
          r="16"
          fill="none"
          className="stroke-current text-gray-200 dark:text-neutral-700"
          stroke-width="4"
        ></circle>
        <g className="origin-center -rotate-90 transform">
          <circle
            cx="18"
            cy="18"
            r="16"
            fill="none"
            className="stroke-current text-primary"
            stroke-width="4"
            stroke-dasharray="100"
            stroke-dashoffset="75"
          ></circle>
        </g>
      </svg>
      <div className="absolute top-1/2 start-1/2 transform -translate-y-1/2 -translate-x-1/2"></div>
    </div>
  );
};

export { Progress };
