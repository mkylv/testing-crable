export const breadcrumbs: { [key: string]: string } = {
  dashboard: "Dashboard",
  crawler: "Crawler",
  settings: "Settings",
};
