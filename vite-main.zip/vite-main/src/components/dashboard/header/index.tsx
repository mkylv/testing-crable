import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Fragment } from "react";
import { breadcrumbs } from "./utils";
import { useLocation } from "react-router-dom";

const Header = () => {
  const { pathname } = useLocation();

  const pathItems = pathname.split("/");

  return (
    <header className="z-[21] sticky top-0 bg-secondary p-5 border-b">
      <Breadcrumb>
        <BreadcrumbList>
          {pathItems.slice(1, pathItems.length).map((item, i) => (
            <Fragment key={i}>
              <BreadcrumbItem key={item}>
                <BreadcrumbLink href={`${pathItems.slice(0, i - 1).join("/")}`}>
                  {breadcrumbs[item]}
                </BreadcrumbLink>
              </BreadcrumbItem>
              {i !== pathItems.slice(1, pathItems.length).length - 1 && (
                <BreadcrumbSeparator />
              )}
            </Fragment>
          ))}
        </BreadcrumbList>
      </Breadcrumb>
    </header>
  );
};

export default Header;
