import { SidebarLinkType, useSidebarLinks } from "@/helpers/sidebar-links";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "react-router-dom";
import UserAvatar from "@/components/common/user/user-avatar";
import { Fragment } from "react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useDashboardStore } from "@/stores/dashboard.store";
import { useTheme } from "next-themes";

const SidebarLink = ({
  link,
  open,
}: {
  link: SidebarLinkType;
  open: boolean;
}) => {
  const { theme } = useTheme();

  const { pathname } = useLocation();

  return (
    <div className="relative">
      <Link
        to={link.locked ? "" : link.href}
        target={
          link.locked
            ? "_self"
            : link.href.includes("https")
            ? "_blank"
            : "_self"
        }
        title={link.locked ? "This feature coming soon..." : ""}
        className={cn(
          `h-10 font-medium rounded-lg hover:bg-primary/10 hover:text-primary ease-in-out text-sm duration-300 flex gap-2 items-center px-2.5 py-5`,
          pathname === link.href &&
            "hover:bg-primary shadow-box bg-primary hover:text-primary-foreground text-primary-foreground",
          !open && "justify-center",
          link.locked &&
            "hover:shadow-inherit text-popover-foreground/30 cursor-default bg-transparent hover:bg-transparent hover:text-popover-foreground/30 select-none"
        )}
      >
        <span
          className={cn(
            theme === "light" &&
              pathname === link.href &&
              link.id === "crawler" &&
              "invert"
          )}
        >
          {link.icon}
        </span>
        {open && link.title}
      </Link>
    </div>
  );
};

const Sidebar = () => {
  const { isSidebarOpen, setIsSidebarOpen } = useDashboardStore();
  const { links } = useSidebarLinks();

  return (
    <aside
      className={cn(
        "z-[22] transition-all fixed top-0 shrink-0 lg:h-screen h-full flex flex-col gap-3 bg-secondary border-r",
        isSidebarOpen ? "w-sidebar" : "w-sidebar-collapsed"
      )}
    >
      <div className="relative h-full flex flex-col justify-between px-4 py-8">
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="flex justify-center items-center text-xs w-[32px] h-[32px] z-[23] top-24 border absolute rounded-full bg-secondary -right-[18px]"
        >
          {isSidebarOpen ? <ArrowLeft size={14} /> : <ArrowRight size={14} />}
        </button>
        <div className="flex flex-col gap-3">
          {links.map((link) => (
            <Fragment key={link.id}>
              <SidebarLink key={link.id} link={link} open={isSidebarOpen} />
              {link.withDivider && <hr />}
            </Fragment>
          ))}
        </div>
        <div className={cn("flex flex-col gap-3", isSidebarOpen && "px-2")}>
          <UserAvatar open={isSidebarOpen} />
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
