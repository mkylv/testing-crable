import { cn } from "@/lib/utils";
import { useDashboardStore } from "@/stores/dashboard.store";
import { ReactNode } from "react";

export function DashboardContainer({ children }: { children: ReactNode }) {
  const { isSidebarOpen } = useDashboardStore();

  return (
    <section
      className={cn(
        "w-full flex flex-col",
        isSidebarOpen ? "pl-sidebar" : "pl-sidebar-collapsed"
      )}
    >
      {children}
    </section>
  );
}
