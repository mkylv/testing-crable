import { CircleUser } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../../ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../../ui/dropdown-menu";
import { Link, useNavigate } from "react-router-dom";
import { CaretRight } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";
import { useLogout } from "@/api/auth/hook";
import { toast } from "@/components/ui/use-toast";
import { useUserStore } from "@/stores/user.store";

const UserAvatar = ({ open }: { open?: boolean }) => {
  const navigate = useNavigate();

  const { mutateAsync: logout } = useLogout();

  const { user } = useUserStore();

  if (!user) return null;

  const { firstName, lastName, profilePicture } = user;

  const AvatarItem = ({ className }: { className?: string }) => (
    <Avatar className={cn("border", className)}>
      <AvatarImage className="object-cover" src={profilePicture} />
      <AvatarFallback className="bg-secondary">
        {firstName && lastName ? (
          <>
            {firstName?.charAt(0).toUpperCase()}
            {lastName?.charAt(0).toUpperCase()}
          </>
        ) : (
          <CircleUser className="h-5 w-5" />
        )}
      </AvatarFallback>
    </Avatar>
  );

  return (
    <div className="flex justify-between items-center">
      {open && (
        <div className="flex gap-4 items-center">
          <AvatarItem />
          <span className="font-semibold">
            {firstName && lastName ? (
              <span>
                {firstName} {lastName}
              </span>
            ) : (
              <>My Account</>
            )}
          </span>
        </div>
      )}
      <DropdownMenu>
        <DropdownMenuTrigger>
          {open ? (
            <button className="text-xl mt-3">
              <CaretRight />
            </button>
          ) : (
            <AvatarItem className={"cursor-pointer"} />
          )}
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align={open ? "end" : "start"}
          className="m-2 bg-background text-foreground"
        >
          <DropdownMenuItem asChild>
            <Link to="/dashboard/settings">Settings</Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link to="/dashboard/support">Support</Link>
          </DropdownMenuItem>

          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <button
              className="w-full"
              onClick={async () => {
                try {
                  const res = await logout();

                  if (res.ok) navigate("/");
                } catch (e: any) {
                  toast({
                    title: "Authentication error",
                    description: e.message,
                    variant: "destructive",
                  });
                }
              }}
            >
              Logout
            </button>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default UserAvatar;
