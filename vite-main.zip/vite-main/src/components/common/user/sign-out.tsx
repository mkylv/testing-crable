import { useLogout } from "@/api/auth/hook";
import { Button } from "../../ui/button";
import { DoorOpen } from "@phosphor-icons/react";

const SignOut = () => {
  const { mutateAsync: logout } = useLogout();

  return (
    <Button
      className="text-lg flex gap-2 items-center"
      variant={"destructive"}
      onClick={async () => await logout()}
    >
      <DoorOpen weight="bold" className="w-4 h-4" /> Sign out
    </Button>
  );
};

export default SignOut;
