import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { ReactNode, useState } from "react";
import { cn, reorderObject } from "@/lib/utils";
import { DotsSixVertical } from "@phosphor-icons/react";
import { Draggable, Droppable } from "react-beautiful-dnd";
import useDragDrop from "@/hooks/drag-and-drop";
import { useMergedRef } from "@mantine/hooks";
import { useScrollRestoration } from "use-scroll-restoration";

export type TabArray = {
  [key: string]: {
    title: string;
    component?: ReactNode | ((data: any) => ReactNode);
  };
};

const InnerTabs = <T extends string>({
  states,
  tabs,
  provided,
}: {
  states: {
    currentSelected: string;
    setCurrentSelected: (tab: string) => void;
  };
  provided: any;
  tabs: TabArray;
}) => {
  const { setUrlFilter } = useCrawlerUrlsStore();

  const { ref } = useScrollRestoration("_", {
    debounceTime: 200,
  });

  const mergedRef = useMergedRef(provided.innerRef, ref);

  return (
    <div
      ref={mergedRef}
      className="flex gap-3 overflow-x-auto pb-2 overscroll-none"
      {...provided.droppableProps}
    >
      {Object.keys(tabs).map((_tab, i) => (
        <Draggable key={_tab} draggableId={_tab} index={i}>
          {(provided, _snapshot) => (
            <button
              ref={provided.innerRef}
              onClick={() => {
                states.setCurrentSelected(_tab as T);
                setUrlFilter("all");
              }}
              className={cn(
                "bg-background/50 flex gap-1 items-center text-sm text-nowrap px-3 py-1 rounded-md hover:bg-background/30 text-foreground",
                states.currentSelected === _tab && "!bg-foreground/10"
              )}
              {...provided.draggableProps}
              {...provided.dragHandleProps}
            >
              {states.currentSelected === _tab && <DotsSixVertical />}{" "}
              {tabs[_tab] && tabs[_tab].title}
            </button>
          )}
        </Draggable>
      ))}
    </div>
  );
};

const RenderTabs = ({
  tabs: _tabs,
  states,
}: {
  tabs: TabArray;
  states: {
    currentSelected: string;
    setCurrentSelected: (tab: string) => void;
  };
}) => {
  const [tabs, setTabs] = useState<TabArray>(_tabs);

  const onDragEnd = (result: any) => {
    if (!result.destination) {
      return;
    }

    const newTabs = reorderObject(
      tabs,
      result.source.index,
      result.destination.index
    );

    setTabs(newTabs);
  };

  const { Provider } = useDragDrop(onDragEnd);

  return (
    <Provider>
      <Droppable droppableId="urls-tabs" direction="horizontal">
        {(provided, _snapshot) => (
          <InnerTabs states={states} tabs={tabs} provided={provided} />
        )}
      </Droppable>
    </Provider>
  );
};

export default RenderTabs;
