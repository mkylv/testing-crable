import { ReactNode } from "react";
import {
  ContextMenuItem,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
} from "@/components/ui/context-menu";
import { ArrowSquareOut, Copy, MagnifyingGlass } from "@phosphor-icons/react";
import { useToast } from "@/components/ui/use-toast";
import { Link } from "react-router-dom";

export const CopyUrl = ({ url }: { url: string }) => {
  const { toast } = useToast();

  return (
    <button
      onClick={() => {
        navigator.clipboard.writeText(url);
        toast({
          title: "Copied!",
        });
      }}
      className="flex gap-2 items-center"
    >
      <Copy className="w-4 h-4" /> <span className="font-medium">Copy</span>
    </button>
  );
};

export const OpenInNewPage = ({ url }: { url: string }) => {
  return (
    <Link className="flex gap-2 items-center" to={url} target="_blank">
      <ArrowSquareOut className="w-4 h-4" /> <span>Open in new page</span>
    </Link>
  );
};

export const CheckIndexMenu = ({ url }: { url: string }) => {
  const links = {
    google: "https://www.google.com/search?q=site:",
    yahoo: "https://search.yahoo.com/search?p=url:",
    bing: "https://www.bing.com/search?q=url:",
    yandex: "https://www.yandex.com/search/?text=url:",
  };

  const LinkElement = ({
    href,
    content,
  }: {
    href: string;
    content: ReactNode;
  }) => {
    return (
      <ContextMenuItem>
        <Link
          to={href}
          target="_blank"
          className="w-full flex gap-2 items-center justify-center"
        >
          {content}
        </Link>
      </ContextMenuItem>
    );
  };

  return (
    <ContextMenuSub>
      <ContextMenuSubTrigger>
        <button className="flex gap-2 items-center">
          <MagnifyingGlass className="w-4 h-4" /> <span>Check Index</span>
        </button>
      </ContextMenuSubTrigger>
      <ContextMenuSubContent className="!w-8 ml-1">
        <LinkElement href={`${links.google}${url}`} content={<>Google</>} />
        <LinkElement href={`${links.yahoo}${url}`} content={<>Yahoo</>} />
        <LinkElement href={`${links.bing}${url}`} content={<>Bing</>} />
        <LinkElement href={`${links.yandex}${url}`} content={<>Yandex</>} />
        <ContextMenuItem>
          <button
            onClick={() => {
              window.open(`${links.google}${url}`);
              window.open(`${links.yahoo}${url}`);
              window.open(`${links.bing}${url}`);
              window.open(`${links.yandex}${url}`);
            }}
            className="w-full flex gap-2 items-center justify-center"
          >
            All
          </button>
        </ContextMenuItem>
      </ContextMenuSubContent>
    </ContextMenuSub>
  );
};
