import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useEffect } from "react";

const CheckUnload = () => {
  const { batchedCrawlData } = useCrawlerDataStore();

  useEffect(() => {
    if (batchedCrawlData.length > 0) {
      window.onbeforeunload = () => true;
      return () => {
        window.onbeforeunload = null;
      };
    }
  }, [batchedCrawlData]);

  return null;
};

export default CheckUnload;
