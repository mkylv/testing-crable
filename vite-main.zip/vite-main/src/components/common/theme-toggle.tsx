import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  const changeTheme = () => {
    switch (theme) {
      case "light": {
        setTheme("dark");
        break;
      }
      case "dark": {
        setTheme("light");
        break;
      }
    }
  };

  return (
    <button
      onClick={changeTheme}
      className="ease-in-out duration-300 hover:scale-125 bg-secondary border text-2xl rounded-full p-3 fixed bottom-7 right-7"
    >
      {theme === "light" && <Moon />}
      {theme === "dark" && <Sun />}
    </button>
  );
}
