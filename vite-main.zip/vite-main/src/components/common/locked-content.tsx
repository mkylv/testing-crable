import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Alarm } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";

const LockedContent = ({
  className,
  side,
}: {
  className?: { icon?: string; container?: string };
  side?: "top" | "bottom" | "left" | "right";
}) => (
  <div
    className={cn(
      "filter-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
      className && className.container
    )}
  >
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger className="ring-0 outline-0 border-none">
          <Alarm
            weight="bold"
            className={cn(
              "animate-bounce w-10 h-10 text-primary",
              className && className.icon
            )}
          />
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <p>This feature will be added soon...</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  </div>
);

export default LockedContent;
