const Loading = () => {
  return (
    <div className="animate-pulse flex justify-center items-center h-screen">
      <img
        src="/logo.svg"
        alt="crable"
        className="w-[200px] h-[200px] transform transition-transform duration-2000 ease-in-out scale-110"
      />
    </div>
  );
};

export default Loading;
