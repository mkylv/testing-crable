import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { CaretLeft } from "@phosphor-icons/react";
import { useState } from "react";

const TruncateText = ({
  content,
  max = 36,
  className,
}: {
  content: string;
  max?: number;
  className?: string;
}) => {
  const [full, setFull] = useState(false);

  return (
    <span className={cn("text-nowrap", className)}>
      {content ? (
        content.length > max ? (
          full ? (
            <span className="flex gap-2 items-center">
              {content}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <CaretLeft
                      onClick={(e) => {
                        e.stopPropagation();
                        setFull((state) => !state);
                      }}
                    />
                  </TooltipTrigger>
                  <TooltipContent>
                    <>Collapse</>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </span>
          ) : (
            <span>
              {content.slice(0, max)}{" "}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setFull((state) => !state);
                      }}
                    >
                      ...
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <>Expand</>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </span>
          )
        ) : (
          content
        )
      ) : (
        "-"
      )}
      {/* {content || "-"} */}
    </span>
  );
};

export default TruncateText;
