import { z } from "zod";

export type renderingTypes = "exact_url" | "all";

export const schema = z.object({
  url: z
    .string()
    .min(1, "Oops... Looks like you didn't add magic")
    .refine(
      (url) =>
        /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/\S*)?$/.test(url),
      {
        message: "Please, enter valid url",
      }
    ),
  js_rendering: z.boolean(),
  type: z.enum(["exact_url", "all"]),
});

export type TCrawler = z.infer<typeof schema>;
