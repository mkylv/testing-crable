import { useForm } from "react-hook-form";
import { renderingTypes, schema, TCrawler } from "./utils";
import { zodResolver } from "@hookform/resolvers/zod";
import useCrawler from "@/hooks/crawler.hook";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Globe, Pause, Play } from "lucide-react";
import {
  ArrowDown,
  LineSegment,
  LineSegments,
  Link,
} from "@phosphor-icons/react";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import CrawlProgress from "../progress";
import { useCrawlerUtilStore } from "@/stores/crawler/util.store";

export default function CrawlerForm() {
  const {
    formState: { errors },
    reset,
    register,
    handleSubmit,
    watch,
    setValue,
    setError,
  } = useForm<TCrawler>({
    resolver: zodResolver(schema),
    defaultValues: {
      url: "",
      js_rendering: false,
      type: "all",
    },
  });

  const renderingType = watch("js_rendering");
  const type = watch("type");

  const { status } = useCrawlerUtilStore();

  const { resetCrawling, startCrawling, pauseCrawl } = useCrawler(reset);

  return (
    <form
      onSubmit={handleSubmit(startCrawling)}
      className="shrink-0 flex lg:flex-row md:flex-row flex-col gap-4 lg:items-center md:items-center items-stretch"
    >
      <div className="w-full flex flex-col relative">
        <Input
          placeholder="https://"
          startIcon={<Globe size={18} />}
          className="placeholder:text-muted-foreground/50"
          {...register("url")}
        />
        {errors && errors.url && errors.url.message && (
          <span className="absolute top-12 text-sm text-destructive">
            {errors.url.message}
          </span>
        )}
      </div>
      <div className="flex gap-2 items-center">
        <Switch
          checked={renderingType}
          onCheckedChange={(checked) => setValue("js_rendering", checked)}
        />
        <span className="text-nowrap">JavaScript Rendering</span>
      </div>
      <Select
        value={type}
        onValueChange={(value) => setValue("type", value as renderingTypes)}
      >
        <SelectTrigger
          icon={<ArrowDown className="w-4 h-4 opacity-75" />}
          className="h-10 lg:w-[300px] md:w-[250px] w-full"
        >
          <SelectValue
            defaultValue={"subdomain"}
            placeholder={
              <div className="flex gap-2 items-center">
                <LineSegment className="w-4 h-4" /> Subdomain
              </div>
            }
          />
        </SelectTrigger>
        <SelectContent>
          {/* <SelectItem value="subfolder">
          <div className="flex gap-2 items-center">
            <FolderOpen className="w-4 h-4" /> Subfolder
          </div>
        </SelectItem> */}
          <SelectItem value="all">
            <div className="flex gap-2 items-center">
              <LineSegments className="w-4 h-4" /> All subdomains
            </div>
          </SelectItem>
          <SelectItem value="exact_url">
            <div className="flex gap-2 items-center">
              <Link className="w-4 h-4" /> Exact URLs
            </div>
          </SelectItem>
        </SelectContent>
      </Select>
      {/* Conditionals */}
      {(status === "not-started" ||
        status === "done" ||
        status === "paused") && (
        <Button key="crawler-starter" type="submit" className="flex gap-1">
          <Play className="w-5 h-5" />
          Start
        </Button>
      )}
      {status === "stopping" && (
        <Button disabled key="crawler-stopper" className="flex gap-1">
          Stopping...
        </Button>
      )}
      {status === "in-progress" && (
        <Button
          key="crawler-pauser"
          variant={"secondary"}
          onClick={pauseCrawl}
          className="flex gap-1"
        >
          <Pause className="w-5 h-5" />
          Pause
        </Button>
      )}
      {/* Progress */}
      {status === "in-progress" && <CrawlProgress />}
      {/* Progress */}
      <Button
        onClick={resetCrawling}
        className="flex gap-1"
        variant={"secondary"}
        type="button"
        disabled={status === "in-progress"}
      >
        Reset
      </Button>
    </form>
  );
}
