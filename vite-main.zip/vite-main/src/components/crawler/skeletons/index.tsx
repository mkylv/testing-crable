import { ReactNode } from "react";
import { Card } from "../../ui/card";
import { Separator } from "../../ui/separator";

const ContainerLayout = ({ children }: { children: ReactNode }) => {
  return (
    <Card className="animate-pulse h-[500px] w-auto p-5 flex flex-col gap-5 rounded-lg">
      {children}
    </Card>
  );
};

const ContainerType1 = () => (
  <ContainerLayout>
    <div className="flex gap-4 items-center">
      <div className="w-24 bg-gradient-to-l from-transparent to-popover/10 h-8 rounded-lg p-2">
        <div className="h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
      </div>
      <div className="w-36 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-20 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-6 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-12 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
    </div>
    <div className="flex w-36 bg-gradient-to-l from-transparent to-popover/10 h-8 rounded-lg p-2">
      <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
      <div className="w-full h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
    </div>
    <div className="w-36 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
    <div className="my-5 flex flex-col gap-9">
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
          <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          <div className="w-16 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        </div>
        <div className="w-16 h-4 bg-popover/10 rounded-full"></div>
      </div>
      <Separator orientation="horizontal" className="bg-popover/10" />
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
          <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          <div className="w-12 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        </div>
        <div className="w-24 h-4 bg-popover/10 rounded-full"></div>
      </div>
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
          <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          <div className="w-10 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        </div>
        <div className="w-12 h-4 bg-popover/10 rounded-full"></div>
      </div>
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
          <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          <div className="w-16 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        </div>
        <div className="w-20 h-4 bg-popover/10 rounded-full"></div>
      </div>
      <div className="flex justify-between items-center">
        <div className="flex gap-4 items-center">
          <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          <div className="w-12 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        </div>
        <div className="w-14 h-4 bg-popover/10 rounded-full"></div>
      </div>
    </div>
  </ContainerLayout>
);

const ContainerType2 = () => (
  <ContainerLayout>
    <div className="flex gap-4 items-center">
      <div className="w-36 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-24 bg-gradient-to-l from-transparent to-popover/10 h-8 rounded-lg p-2">
        <div className="h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
      </div>
      <div className="w-20 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-6 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-12 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      <div className="w-20 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
    </div>
    <div className="flex justify-between items-center">
      <div className="flex w-36 bg-gradient-to-l from-transparent to-popover/10 h-8 rounded-lg p-2">
        <div className="w-3 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        <div className="w-full h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
      </div>
      <div className="flex gap-3 items-center">
        <div className="w-20 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
        <div className="w-24 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
        <div className="w-12 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
        <div className="w-20 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
        <div className="w-8 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
        <div className="w-12 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
      </div>
    </div>
    <div className="w-36 h-4 bg-gradient-to-l from-transparent to-popover/10 rounded-full"></div>
    <div className="my-5 flex flex-col gap-9">
      <div className="flex justify-between items-center px-5">
        <div className="w-16 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        <div className="w-16 h-4 bg-popover/10 rounded-full"></div>
      </div>
      <Separator orientation="horizontal" className="bg-popover/10" />
      <div className="flex justify-between items-center px-5">
        <div className="w-12 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        <div className="flex w-24 justify-start">
          <div className="w-24 bg-gradient-to-l from-transparent to-informational/30 h-8 rounded-lg p-2">
            <div className="h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          </div>
        </div>
      </div>
      <div className="flex justify-between items-center px-5">
        <div className="w-10 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        <div className="flex w-24 justify-start">
          <div className="w-[72px] bg-gradient-to-l from-transparent to-warning/30 h-8 rounded-lg p-2">
            <div className="h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          </div>
        </div>
      </div>
      <div className="flex justify-between items-center px-5">
        <div className="w-16 h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
        <div className="flex w-24 justify-start">
          <div className="w-20 bg-gradient-to-l from-transparent to-destructive/30 h-8 rounded-lg p-2">
            <div className="h-4 bg-gradient-to-r from-transparent to-popover/10 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  </ContainerLayout>
);

const CrawlTableSkeletons = () => {
  return (
    <div className="grid lg:grid-cols-2 grid-cols-1 gap-6">
      <ContainerType1></ContainerType1>
      <ContainerType2></ContainerType2>
      <ContainerType1></ContainerType1>
      <ContainerType2></ContainerType2>
    </div>
  );
};

export default CrawlTableSkeletons;
