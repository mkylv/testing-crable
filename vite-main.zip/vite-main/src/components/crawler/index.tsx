import CrawlTables from "./crawl-tables";
import { useCrawlerUtilStore } from "@/stores/crawler/util.store";
import CrawlNotStarted from "./not-started";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import CrawlTableSkeletons from "./skeletons";
import CrawlerForm from "./crawl-form";

const Crawler = () => {
  const { batchedCrawlData: crawlData } = useCrawlerDataStore();

  const { status } = useCrawlerUtilStore();

  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Crawler</h1>
        {/* Customize */}
        {/* <div className="flex gap-2">
          <Button className="flex gap-2 items-center">
            Download
            <DownloadSimple className="w-5h h-5" />
          </Button>
          {customizeMode ? (
            <>
              <Button>Save</Button>
              <Button
                onClick={() => setCustomizeMode(false)}
                variant="secondary"
              >
                Cancel
              </Button>
            </>
          ) : (
            <>
              <Button
                onClick={() => setCustomizeMode(true)}
                variant="secondary"
              >
                Customize
              </Button>
            </>
          )}
        </div> */}
      </div>
      <div className="flex flex-col gap-4">
        <CrawlerForm />
        <section className={crawlData.length !== 0 ? "my-8" : "my-2"}>
          {crawlData.length !== 0 ? (
            <CrawlTables />
          ) : (
            <>
              {status === "in-progress" && crawlData.length === 0 ? (
                <CrawlTableSkeletons />
              ) : (
                <CrawlNotStarted />
              )}
            </>
          )}
        </section>
      </div>
    </div>
  );
};

export default Crawler;
