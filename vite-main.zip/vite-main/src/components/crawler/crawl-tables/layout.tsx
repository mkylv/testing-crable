import { Card } from "@/components/ui/card";
import { ReactNode } from "react";

const CrawlItemLayout = ({ children }: { children: ReactNode }) => {
  return (
    <Card className="h-[500px] w-auto p-5 flex flex-col gap-5 rounded-lg">
      {children}
    </Card>
  );
};

export default CrawlItemLayout;
