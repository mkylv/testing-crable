import { cn } from "@/lib/utils";
import { ReactNode } from "react";

const Badge = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) => {
  return (
    <span
      className={cn(
        "flex w-min gap-1 items-center justify-center text-sm py-1 px-2 rounded font-medium",
        className
      )}
    >
      {children}
    </span>
  );
};

export default Badge;
