import TruncateText from "@/components/common/text-truncater";
import useCrawlFilters from "@/hooks/use-filter.hook";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { X } from "@phosphor-icons/react";
import { useMemo } from "react";

const FilterElement = ({
  _key,
  value,
  callback,
}: {
  _key: string;
  value: string;
  callback: () => void;
}) => {
  return (
    <button
      onClick={callback}
      className="rounded bg-secondary border border-border-secondary text-foreground px-3 py-2 flex gap-2 items-center "
    >
      <span>{_key}:</span>
      <span>
        {value.length > 24 ? <TruncateText max={24} content={value} /> : value}
      </span>
      <button type="button">
        <X className="w-3 h-3" />
      </button>
    </button>
  );
};

const CrawlFilters = () => {
  const { filters, filterExists } = useCrawlFilters();

  return (
    <div className="text-nowrap text-sm flex gap-3 items-center flex-wrap">
      {filters.issueBatch.exists && (
        <FilterElement
          _key="Selected issue"
          value={filters.issueBatch.get.split("_").join(" ")}
          callback={() => filters.issueBatch.set("")}
        />
      )}
      {filters.responseTime.exists && (
        <FilterElement
          _key="Response time"
          value={`${+filters.responseTime.get - 1} - ${
            filters.responseTime.get
          }`}
          callback={() => filters.responseTime.set("all")}
        />
      )}
      {filterExists && (
        <button
          onClick={() => {
            for (const key of Object.keys(filters)) {
              filters[key].set(filters[key].defaultValue);
            }
          }}
        >
          Clear all filters
        </button>
      )}
    </div>
  );
};

export default CrawlFilters;
