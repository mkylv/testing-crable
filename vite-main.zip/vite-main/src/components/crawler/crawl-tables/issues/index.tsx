import RenderTabs from "@/components/common/crawler/tab-renderer";
import CrawlItemLayout from "../layout";
import { tabTypes, tabs } from "./tabs";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";

const Issues = () => {
  const { selectedIssueTab: tab, setSelectedIssueTab: setTab } =
    useCrawlerUrlsStore();

  return (
    <CrawlItemLayout>
      <div className="flex flex-col w-full">
        <RenderTabs
          tabs={tabs}
          states={{
            currentSelected: tab,
            setCurrentSelected: setTab,
          }}
        />
      </div>
      {tabs[tab as tabTypes].component}
    </CrawlItemLayout>
  );
};

export default Issues;
