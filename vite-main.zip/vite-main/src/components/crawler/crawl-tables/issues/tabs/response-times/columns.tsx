import { ArrowUpDown } from "lucide-react";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";

export const useGetColumns = () => {
  const { batchedCrawlData } = useCrawlerDataStore();

  const { setSelectedResponseTime } = useCrawlerUrlsStore();

  const columns: any = [
    {
      accessorKey: "response_time",
      header: "Response Time (in seconds)",
      cell: ({ row }: any) => (
        <button
          className="text-left"
          onClick={() => setSelectedResponseTime(row.original.ceil)}
        >
          {row.original.ceil - 1} - {row.original.ceil}
        </button>
      ),
    },
    {
      accessorKey: "length",
      header: ({ column }: any) => {
        return (
          <button
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            className="flex gap-2 items-center text-nowrap"
          >
            Length
            <ArrowUpDown className="h-4 w-4" />
          </button>
        );
      },
      cell: ({ row }: any) => <>{row.original.urls.length}</> || "-",
    },
    {
      accessorKey: "priority",
      header: ({ column }: any) => {
        return (
          <button
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            className="flex gap-2 items-center text-nowrap"
          >
            % of total
            <ArrowUpDown className="h-4 w-4" />
          </button>
        );
      },
      cell: ({ row }: any) =>
        (
          <>
            {(
              (row.original.urls.length * 100) /
              batchedCrawlData.filter((d) => d?.url_detail?.response_time)
                .length
            ).toFixed(1)}
          </>
        ) || "-",
    },
  ];

  return { columns };
};
