import Issues from "./issues";
import Overview from "./overview";
import ResponseTimes from "./response-times";

export type tabTypes =
  | "overview"
  | "issues"
  // | "site-structure"
  // | "segmnts"
  | "response-times";
// | "api";
// | "spelling-grammar";

export const tabs = {
  overview: {
    title: "Overview",
    component: <Overview />,
  },
  issues: {
    title: "Issues",
    component: <Issues />,
  },
  // "site-structure": {
  //   title: "Site Structure",
  //   component: <></>,
  // },
  "response-times": {
    title: "Response Times",
    component: <ResponseTimes />,
  },
  // api: {
  //   title: "API",
  //   component: <></>,
  // },
};
