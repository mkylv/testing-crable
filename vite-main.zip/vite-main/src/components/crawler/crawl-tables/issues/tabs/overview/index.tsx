import {
  Table,
  TableBody,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import CrawlSummary from "./summary";

const Issues = () => {
  return (
    <Table parentClassName="h-[380px]">
      <TableHeader>
        <TableRow>
          <TableHead></TableHead>
          <TableHead>URLs</TableHead>
          <TableHead>% of total</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <CrawlSummary />
      </TableBody>
    </Table>
  );
};

export default Issues;
