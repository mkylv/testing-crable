import { ArrowDown, ArrowUp } from "@phosphor-icons/react";
import { ReactNode } from "react";

export const issueTypes: {
  [key: string]: { text: ReactNode; className: string };
} = {
  warning: {
    text: "Warning",
    className: "text-warning bg-warning/20",
  },
  issues: {
    text: "Issue",
    className: "text-destructive bg-destructive/20",
  },
  opportunity: {
    text: "Opportunity",
    className: "text-informational bg-informational/20",
  },
};

export const priorityTypes: {
  [key: string]: { text: ReactNode; className: string };
} = {
  high: {
    text: (
      <>
        <ArrowUp /> High
      </>
    ),
    className: "text-destructive bg-destructive/20",
  },
  medium: {
    text: <>Medium</>,
    className: "text-warning bg-warning/20",
  },
  low: {
    text: (
      <>
        <ArrowDown /> Low
      </>
    ),
    className: "text-informational bg-informational/20",
  },
};
