import { TableCell, TableRow } from "@/components/ui/table";
import { CaretDown, CaretRight } from "@phosphor-icons/react";
import { useState } from "react";

const CrawlDataDropdown = () => {
  const [generalCollapse, setGeneralCollapse] = useState(false);

  // const rows = [
  //   {
  //     name: "internal",
  //     title: "Internal",
  //     children: [
  //       {
  //         name: "all",
  //         title: "All",
  //       },
  //       {
  //         name: "image",
  //         title: "Images",
  //       },
  //       {
  //         name: "canonical",
  //         title: "Canonicals",
  //       },
  //       {
  //         name: "static",
  //         title: "Statics",
  //       },
  //     ],
  //   },
  //   {
  //     name: "external",
  //     title: "External",
  //     children: [
  //       {
  //         name: "all",
  //         title: "All",
  //       },
  //       {
  //         name: "image",
  //         title: "Images",
  //       },
  //       {
  //         name: "canonical",
  //         title: "Canonicals",
  //       },
  //       {
  //         name: "static",
  //         title: "Statics",
  //       },
  //     ],
  //   },
  //   {
  //     name: "security",
  //     title: "Security",
  //     children: [
  //       {
  //         name: "all",
  //         title: "All",
  //       },
  //       {
  //         name: "image",
  //         title: "Images",
  //       },
  //       {
  //         name: "canonical",
  //         title: "Canonicals",
  //       },
  //       {
  //         name: "static",
  //         title: "Statics",
  //       },
  //     ],
  //   },
  // ];

  // const RowSet = ({ row }: { row: any }) => {
  //   const { batchedCrawlData } = useCrawlerDataStore();

  //   const crawlData =
  //     row.name === "internal" || row.name === "security"
  //       ? batchedCrawlData
  //       : CrawlFilter.filter(batchedCrawlData, {
  //           key: "type",
  //           value: row.name,
  //         });

  //   const [collapsed, setCollapsed] = useState(
  //     row.name === "internal" ? false : true
  //   );

  //   return (
  //     <>
  //       <TableRow>
  //         <TableCell
  //           className="pl-10 cursor-pointer flex gap-2 items-center"
  //           onClick={() => setCollapsed((state) => !state)}
  //         >
  //           {collapsed ? <CaretRight /> : <CaretDown />} {row.title}
  //         </TableCell>
  //       </TableRow>
  //       {!collapsed && (
  //         <>
  //           {row.children.map((child: any) => {
  //             const data =
  //               child.name === "all"
  //                 ? crawlData
  //                 : CrawlFilter.filter(crawlData, {
  //                     key: "type",
  //                     value: child.name,
  //                   });

  //             const dataLen = data.length;

  //             return (
  //               <TableRow key={child.name}>
  //                 <TableCell className="pl-20">{child.title}</TableCell>
  //                 <TableCell>{dataLen}</TableCell>
  //                 <TableCell>
  //                   {((dataLen * 100) / crawlData.length).toFixed(1)}%
  //                 </TableCell>
  //               </TableRow>
  //             );
  //           })}
  //         </>
  //       )}
  //     </>
  //   );
  // };

  return (
    <>
      <TableRow>
        <TableCell
          className="cursor-pointer flex gap-2 items-center"
          onClick={() => setGeneralCollapse((state) => !state)}
        >
          {generalCollapse ? <CaretRight /> : <CaretDown />} Crawl Data
        </TableCell>
      </TableRow>
      {!generalCollapse && (
        <>
          {/* {rows.map((row) => {
            return <RowSet row={row} key={row.name} />;
          })} */}
        </>
      )}
    </>
  );
};

export default CrawlDataDropdown;
