import { useRef } from "react";

import { DataTable } from "@/components/ui/data-table";
import { useGetColumns } from "./columns";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";

const Issues = () => {
  const { rawIssues, issues } = useCrawlerDataStore();

  const { columns } = useGetColumns();

  const tableRef = useRef<any>(null);

  const applyFilter = (filterValue: string) => {
    if (tableRef.current) {
      const table = tableRef.current.table;
      table.getColumn("issue_type")?.setFilterValue(filterValue);
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <div />
        <div className="flex gap-4 text-sm font-medium">
          <button
            onClick={() => applyFilter("issues")}
            className="hover:underline text-destructive p-1"
          >
            Issues:{" "}
            {rawIssues.filter((issue) => issue.issue_type == "issues").length}
          </button>
          <button
            onClick={() => applyFilter("warning")}
            className="hover:underline text-warning p-1"
          >
            Warning:{" "}
            {rawIssues.filter((issue) => issue.issue_type == "warning").length}
          </button>
          <button
            onClick={() => applyFilter("opportunity")}
            className="hover:underline text-informational p-1"
          >
            Opportunities:{" "}
            {
              rawIssues.filter((issue) => issue.issue_type == "opportunity")
                .length
            }
          </button>
          <button
            onClick={() => applyFilter("")}
            className="hover:underline text-foreground p-1"
          >
            Total: {rawIssues.length}
          </button>
        </div>
      </div>
      <div className="h-[340px] border rounded-md overscroll-none overflow-auto">
        <DataTable columns={columns} data={issues} ref={tableRef} />
      </div>
    </div>
  );
};

export default Issues;
