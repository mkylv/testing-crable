import { cn } from "@/lib/utils";
import Badge from "../../../components/badge";
import { issueTypes, priorityTypes } from "./utils";
import { ArrowUpDown } from "lucide-react";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";

export const useGetColumns = () => {
  const { setSelectedIssueBatch, setSelectedUrlTab } = useCrawlerUrlsStore();
  const { rawIssues } = useCrawlerDataStore();

  const URL_TABS: { [key: string]: string } = {
    url: "internals",
    meta_description: "meta-description",
    response_code: "response-codes",
    title: "page-titles",
    h1: "h1",
    h2: "h2",
    img: "images",
  };

  const columns: any = [
    {
      accessorKey: "description",
      header: "Issue name",
      cell: ({ row }: any) => (
        <button
          className="text-left"
          onClick={() => {
            setSelectedIssueBatch(row.original.title);
            setSelectedUrlTab(URL_TABS[row.original.element]);
          }}
        >
          {row.original.description}
        </button>
      ),
    },
    {
      accessorKey: "issue_type",
      header: ({ column }: any) => {
        return (
          <button
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            className="flex gap-2 items-center text-nowrap"
          >
            Issue type
            <ArrowUpDown className="h-4 w-4" />
          </button>
        );
      },
      cell: ({ row }: any) =>
        (
          <>
            {issueTypes[row.original.issue_type] && (
              <Badge className={issueTypes[row.original.issue_type].className}>
                {issueTypes[row.original.issue_type].text}
              </Badge>
            )}
          </>
        ) || "-",
    },
    {
      accessorKey: "priority",
      header: ({ column }: any) => {
        return (
          <button
            onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            className="flex gap-2 items-center text-nowrap"
          >
            Issue priority
            <ArrowUpDown className="h-4 w-4" />
          </button>
        );
      },
      cell: ({ row }: any) =>
        (
          <>
            {priorityTypes[row.original.priority] && (
              <Badge
                className={cn(
                  "whitespace-none",
                  priorityTypes[row.original.priority].className
                )}
              >
                {priorityTypes[row.original.priority].text}
              </Badge>
            )}
          </>
        ) || "-",
    },
    {
      accessorKey: "urls",
      header: "URL's",
      cell: ({ row }: any) => {
        return row.original.issues.length || "-";
      },
    },
    {
      accessorKey: "issues_percent",
      header: "% of total",
      cell: ({ row }: any) =>
        (
          <>
            {((row.original.issues.length * 100) / rawIssues.length).toFixed(1)}
            %
          </>
        ) || "-",
    },
  ];

  return { columns };
};
