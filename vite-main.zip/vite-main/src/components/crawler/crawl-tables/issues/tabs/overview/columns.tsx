import { useCrawlerDataStore } from "@/stores/crawler/data.store";

export const useGetColumns = (data: any, setSelectedIssueBatch: any) => {
  const { issues } = useCrawlerDataStore();

  const columns: any = [
    {
      accessorKey: "description",
      header: "",
      cell: () => <>dropdown</>,
    },
    { accessorKey: "", header: "URLs", cell: () => <>urls</> },
    { accessorKey: "", header: "% of total", cell: () => <>total</> },
  ];

  return { columns };
};
