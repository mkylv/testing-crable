import { TableCell, TableRow } from "@/components/ui/table";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useState } from "react";
import { CaretDown, CaretRight } from "@phosphor-icons/react";
import { CrawlFilter } from "@/lib/crawler/filter";

const CrawlSummary = () => {
  const [collapseSummary, setCollapseSummary] = useState(false);

  const { batchedCrawlData } = useCrawlerDataStore();

  const rows = [
    {
      name: "all",
      title: "Total URLs Encountered",
    },
    {
      name: "page_detail",
      title: "Internal URLs",
    },
    {
      name: "external",
      title: "External URLs",
    },
    {
      name: "image",
      title: "Images",
    },
    {
      name: "canonical",
      title: "Canonicals",
    },
    {
      name: "static",
      title: "Statics",
    },
  ];

  return (
    <>
      <TableRow>
        <TableCell
          className="cursor-pointer flex gap-2 items-center"
          onClick={() => setCollapseSummary((state) => !state)}
        >
          {collapseSummary ? <CaretRight /> : <CaretDown />} Summary
        </TableCell>
      </TableRow>
      {!collapseSummary &&
        rows.map((row) => {
          const data =
            row.name === "all"
              ? batchedCrawlData
              : CrawlFilter.filter(batchedCrawlData, {
                  key: "type",
                  value: row.name,
                });

          const dataLen = data.length;

          return (
            <TableRow key={row.name}>
              <TableCell className="pl-10">{row.title}</TableCell>
              <TableCell>{dataLen}</TableCell>
              <TableCell>
                {((dataLen * 100) / batchedCrawlData.length).toFixed(1)}%
              </TableCell>
            </TableRow>
          );
        })}
    </>
  );
};

export default CrawlSummary;
