import { DataTable } from "@/components/ui/data-table";
import { batchResponseTimes } from "@/lib/crawler";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useMemo } from "react";
import { useGetColumns } from "./columns";

const ResponseTimes = () => {
  const { batchedCrawlData } = useCrawlerDataStore();

  const responseTimes = useMemo(
    () => batchResponseTimes(batchedCrawlData).sort((a, b) => a.ceil - b.ceil),
    [batchedCrawlData]
  );

  const { columns } = useGetColumns();

  return (
    <DataTable
      // @vugar
      className="overflow-auto"
      columns={columns}
      data={responseTimes}
    />
  );
};

export default ResponseTimes;
