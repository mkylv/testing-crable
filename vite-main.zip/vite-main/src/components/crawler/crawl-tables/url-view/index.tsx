import { useEffect } from "react";
import CrawlItemLayout from "../layout";
import { tabTypes, tabs } from "./tabs";

import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import RenderTabs from "@/components/common/crawler/tab-renderer";

const URLView = () => {
  const crawlData = useCrawlerDataStore((state) => state.batchedCrawlData);

  const {
    selectedURL,
    setSelectedURL,
    selectedUrlViewTab: currentSelectedUrlViewTab,
    setSelectedUrlViewTab: setUrlViewTab,
  } = useCrawlerUrlsStore();

  console.log(selectedURL);

  const foundData = crawlData
    .filter((data) => data.type === "page_detail")
    .find((data) => data.url === selectedURL);

  useEffect(() => {
    if (!selectedURL) setSelectedURL(crawlData[0]?.url || "");
  }, [crawlData, selectedURL, setSelectedURL]);

  return (
    <CrawlItemLayout>
      <div className="flex flex-col w-full">
        <RenderTabs
          tabs={tabs}
          states={{
            currentSelected: currentSelectedUrlViewTab,
            setCurrentSelected: setUrlViewTab,
          }}
        />
      </div>
      {tabs[currentSelectedUrlViewTab as tabTypes].component(foundData)}
    </CrawlItemLayout>
  );
};

export default URLView;
