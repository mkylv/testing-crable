import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { keysToTake } from "./definitions";

const UrlDetails = ({ data }: { data: any }) => {
  if (!data) return <>Please, select URL</>;

  return (
    <div className="flex flex-col gap-2">
      <h2 className="text-xl font-semibold">Content Detail</h2>
      <Table parentClassName="border rounded h-[350px]">
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Value</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {Object.keys(keysToTake).map((key) => (
            <TableRow key={key}>
              <TableCell>{keysToTake[key].title}</TableCell>
              <TableCell>{keysToTake[key].value(data)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default UrlDetails;
