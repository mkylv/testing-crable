import { CopyUrl, OpenInNewPage } from "@/components/common/crawler/context";
import TruncateText from "@/components/common/text-truncater";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Image as IconImage } from "lucide-react";
import { useState } from "react";

const ImageDetails = ({ data }: { data: any }) => {
  const [selectedImageUrl, setSelectedImageUrl] = useState(
    data.image_detail?.[0]?.src
  );

  if (!data) return <>Please, select URL</>;

  const foundImage = data.image_detail?.find(
    (image: any) => image.src === selectedImageUrl
  );

  return (
    <div className="flex flex-col gap-2">
      <h2 className="text-2xl font-semibold">Image Details</h2>
      <ResizablePanelGroup direction="horizontal">
        <ResizablePanel>
          <Table parentClassName="max-h-[300px] border rounded">
            <TableHeader>
              <TableRow>
                <TableHead>To</TableHead>
                <TableHead>Alt</TableHead>
                <TableHead>Content Type</TableHead>
                <TableHead>Size</TableHead>
                <TableHead>xPath</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data && data.image_detail ? (
                data.image_detail.map((image: any, i: number) => (
                  <TableRow key={i}>
                    <TableCell>
                      <ContextMenu>
                        <ContextMenuTrigger>
                          <button
                            className="text-left"
                            onClick={() => setSelectedImageUrl(image?.src)}
                          >
                            {<TruncateText content={image?.src} /> || "-"}
                          </button>
                        </ContextMenuTrigger>
                        <ContextMenuContent>
                          <ContextMenuItem>
                            <OpenInNewPage url={image?.src} />
                          </ContextMenuItem>
                          <ContextMenuSeparator />
                          <ContextMenuItem>
                            <CopyUrl url={foundImage?.src} />
                          </ContextMenuItem>
                        </ContextMenuContent>
                      </ContextMenu>
                    </TableCell>
                    <TableCell>
                      {<TruncateText content={image.alt} /> || "-"}
                    </TableCell>
                    <TableCell>{image.content_type || "-"}</TableCell>
                    <TableCell>
                      {`${image.size.toFixed(2)} KB` || "-"}
                    </TableCell>
                    <TableCell className="text-nowrap">
                      {image.xpath || "-"}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center">
                    No results.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </ResizablePanel>
        <ResizableHandle withHandle />
        <ResizablePanel className="border" defaultSize={50}>
          <div className="p-4 h-full flex flex-col gap-4 justify-center items-center">
            {foundImage && foundImage.src ? (
              <ContextMenu>
                <ContextMenuTrigger>
                  <img
                    src={foundImage?.src}
                    alt={foundImage?.alt}
                    className="shrink-0 w-48 h-48"
                  />
                </ContextMenuTrigger>
                <ContextMenuContent>
                  <ContextMenuItem>
                    <OpenInNewPage url={foundImage?.src} />
                  </ContextMenuItem>
                  <ContextMenuSeparator />
                  <ContextMenuItem>
                    <CopyUrl url={foundImage?.src} />
                  </ContextMenuItem>
                </ContextMenuContent>
              </ContextMenu>
            ) : (
              <>
                <IconImage className="w-24 h-24" />
                <span className="text-xl font-medium">No image selected</span>
              </>
            )}
          </div>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
};

export default ImageDetails;
