import { z } from "zod";

export const formSchema = z.object({
  title: z.string(),
  description: z.string(),
  siteName: z.string(),
  descriptionPrefix: z.string(),
  favicon: z.string(),
  device: z.string(),
});

export type formType = z.infer<typeof formSchema>;
