import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { zodResolver } from "@hookform/resolvers/zod";
import { ChevronRight } from "lucide-react";
import { Fragment, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { formSchema } from "./utils";
import { Button } from "@/components/ui/button";
import SERPFormItem, { styles } from "./_components/form-item";
import { DotsVerticalIcon } from "@radix-ui/react-icons";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { DeviceTypes, getCalculations } from "./formulas";

const SERPSnippet = ({ data }: { data: any }) => {
  const [urlSlices, setUrlSlices] = useState<string[]>([]);

  const defaultObject = useMemo(() => {
    return {
      title: data?.title_detail?.[0]?.title,
      description: data?.meta_description_detail?.[0]?.description,
      siteName: data?.site_title,
      device: "desktop",
      descriptionPrefix: data?.meta_description_detail?.[0]?.prefix,

      favicon: data?.favicon,
    };
  }, [
    data?.favicon,
    data?.meta_description_detail,
    data?.site_title,
    data?.title_detail,
  ]);

  const methods = useForm({
    defaultValues: defaultObject,
    resolver: zodResolver(formSchema),
  });

  const { control, watch, register, reset } = methods;

  useEffect(() => {
    reset(defaultObject);
  }, [data, defaultObject, reset]);

  const title = watch("title");
  const descriptionPrefix = watch("descriptionPrefix");
  // descriptionPrefix + " "
  const description = watch("description");
  const device = watch("device");
  const siteName = watch("siteName");
  const favicon = watch("favicon");

  const titleCalculations = useMemo(
    () => getCalculations(title, "title", device as DeviceTypes),
    [device, title]
  );
  const descriptionCalculations = useMemo(
    () => getCalculations(description, "description", device as DeviceTypes),
    [description, device]
  );

  useEffect(() => {
    setUrlSlices(data?.url?.split("/"));
  }, [data?.url]);

  if (!data) return <>Please, select URL</>;

  return (
    <div className="flex flex-col justify-between">
      <div className="mb-6 py-4 flex gap-12 justify-between items-start overflow-x-scroll">
        {/* SERP */}
        <div className="flex flex-col gap-1">
          <div className="flex gap-3 items-center">
            <div>
              <img
                width={36}
                height={36}
                className="rounded-full border"
                alt="Favicon"
                src={favicon}
              />
            </div>
            <div className="flex flex-col gap-0.5">
              <span>{siteName}</span>
              <div className="flex items-center text-sm">
                <span className="w-36 truncate flex gap-1 items-center">
                  {urlSlices &&
                    urlSlices.slice(2, urlSlices.length).map((slice, i) => (
                      <Fragment key={i}>
                        {slice}{" "}
                        {i !==
                          urlSlices.slice(2, urlSlices.length).length - 2 && (
                          <ChevronRight className="w-4 h-4" />
                        )}
                      </Fragment>
                    ))}
                </span>{" "}
                <DotsVerticalIcon />
              </div>
            </div>
          </div>
          <h3 className="font-medium text-lg text-accent">
            {title?.slice(0, 38)}
            {title?.length > 37 && "..."}
          </h3>
          <p className="text-sm w-[450px]">
            {description?.slice(0, 107)}
            {description?.length > 106 && "..."}
          </p>
        </div>
        <Table
          parentClassName="!overflow-visible border rounded"
          style={
            {
              // width: "100%",
              // backgroundColor: "#2a2a2a",
              // color: "#fff",
            }
          }
        >
          <TableHeader>
            <TableRow>
              {/* style={{ backgroundColor: "#333" }} */}
              <TableHead colSpan={1}></TableHead>
              <TableHead colSpan={3}>Chars</TableHead>
              <TableHead colSpan={3}>Pixels</TableHead>
            </TableRow>
            <TableRow>
              <TableHead>Element</TableHead>
              <TableHead>Length</TableHead>
              <TableHead>Displayed</TableHead>
              <TableHead>Truncated</TableHead>
              <TableHead>Length</TableHead>
              <TableHead>Available</TableHead>
              <TableHead>Remaining</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell>Title</TableCell>
              <TableCell>{titleCalculations.chars.length}</TableCell>
              <TableCell>{titleCalculations.chars.displayed}</TableCell>
              <TableCell
                className={
                  titleCalculations.chars.exceeds
                    ? "text-red-500"
                    : "text-green-500"
                }
              >
                {titleCalculations.chars.truncated}
              </TableCell>
              <TableCell>{titleCalculations.pixels.length}</TableCell>
              <TableCell>{titleCalculations.pixels.available}</TableCell>
              <TableCell
                className={
                  titleCalculations.pixels.exceeds
                    ? "text-red-500"
                    : "text-green-500"
                }
              >
                {titleCalculations.pixels.remaining}
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell>Description</TableCell>
              <TableCell>{descriptionCalculations.chars.length}</TableCell>
              <TableCell>{descriptionCalculations.chars.displayed}</TableCell>
              <TableCell
                className={
                  descriptionCalculations.chars.exceeds
                    ? "text-red-500"
                    : "text-green-500"
                }
              >
                {descriptionCalculations.chars.truncated}
              </TableCell>
              <TableCell>{descriptionCalculations.pixels.length}</TableCell>
              <TableCell>{descriptionCalculations.pixels.available}</TableCell>
              <TableCell
                className={
                  descriptionCalculations.pixels.exceeds
                    ? "text-red-500"
                    : "text-green-500"
                }
              >
                {descriptionCalculations.pixels.remaining}
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>
      <div className="mb-12 gap-3 flex bg-secondary p-3 rounded overflow-x-scroll">
        <Form {...methods}>
          <div className="flex flex-col gap-2">
            <SERPFormItem title="Title">
              <Input
                className={styles.input}
                placeholder="Site title"
                {...register("title")}
              />
            </SERPFormItem>
            <SERPFormItem title="Description">
              <Textarea
                className={styles.input}
                placeholder="Site description"
                {...register("description")}
              />
            </SERPFormItem>
            <div className="flex ml-[104px]">
              <Button
                size={"sm"}
                className="px-2 py-1 text-xs"
                onClick={() => {
                  reset(defaultObject);
                }}
              >
                Reset title & description
              </Button>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <SERPFormItem title="Device">
              <FormField
                control={control}
                name="device"
                render={({ field }) => (
                  <FormItem>
                    <Select
                      value={field.value}
                      onValueChange={(value) => field.onChange(value)}
                    >
                      <FormControl>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue
                            placeholder="Desktop"
                            className="border"
                          />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="desktop">Desktop</SelectItem>
                        <SelectItem value="mobile">Mobile</SelectItem>
                        <SelectItem value="tablet">Tablet</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </SERPFormItem>
            <SERPFormItem title="Site name">
              <Input
                className={styles.input}
                placeholder="Site name"
                {...register("siteName")}
              />
            </SERPFormItem>
            {/* <SERPFormItem title="Description prefix">
              <Input
                className={styles.input}
                placeholder="Description prefix"
                {...register("descriptionPrefix")}
              />
            </SERPFormItem> */}
          </div>
        </Form>
      </div>
    </div>
  );
};

export default SERPSnippet;
