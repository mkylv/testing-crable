import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const CookiesDetails = ({ data }: { data: any }) => {
  if (!data) return <>Please, select URL</>;

  return (
    <div className="flex flex-col gap-2">
      <h2 className="text-2xl font-semibold">Inlinks</h2>
      <Table parentClassName="max-h-[300px] border rounded">
        <TableHeader>
          <TableRow>
            <TableHead>Cookie name</TableHead>
            <TableHead>Cookie value</TableHead>
            <TableHead>Domain</TableHead>
            <TableHead>Path</TableHead>
            <TableHead>Expires</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data?.cookies_detail?.map((cookie: any, i: number) => {
            // console.log(cookie);
            return (
              <TableRow key={i}>
                <TableCell>{cookie.name || "-"}</TableCell>
                <TableCell>{cookie.value || "-"}</TableCell>
                <TableCell>{cookie.domain || "-"}</TableCell>
                <TableCell>{cookie.path || "-"}</TableCell>
                <TableCell>{cookie.expires || "-"}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};

export default CookiesDetails;
