import { getTextWidth } from "@/lib/utils";

export type DeviceTypes = "desktop" | "mobile" | "tablet";

export const getCalculations = (
  content: string,
  format: "title" | "description",
  device: DeviceTypes
) => {
  let lengthLimit = 0,
    widthLimit = 0;

  // check for format and device
  if (format === "title") {
    if (device === "desktop") {
      lengthLimit = 63;
      widthLimit = 560;
    } else if (device === "mobile" || device === "tablet") {
      lengthLimit = 63;
      widthLimit = 582;
    }
  } else if (format === "description") {
    if (device === "desktop") {
      lengthLimit = 161;
      widthLimit = 981;
    } else if (device === "mobile" || device === "tablet") {
      lengthLimit = 164;
      widthLimit = 1013;
    }
  }

  const len = content?.length;
  const displayed = len > lengthLimit ? len - (len - lengthLimit) : len;
  const truncated = len > lengthLimit ? len - lengthLimit : 0;
  const exceeds = len > lengthLimit;

  const contentWidth = +getTextWidth(content, "arial").toFixed(0);
  const available = widthLimit;
  const remaining = widthLimit - contentWidth;
  const exceedsWidth = contentWidth > widthLimit;

  return {
    chars: {
      length: len,
      displayed,
      truncated,
      exceeds,
    },
    pixels: {
      length: contentWidth,
      available,
      remaining,
      exceeds: exceedsWidth,
    },
  };
};
