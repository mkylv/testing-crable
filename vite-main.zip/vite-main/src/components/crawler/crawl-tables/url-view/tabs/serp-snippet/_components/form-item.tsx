import { Label } from "@/components/ui/label";
import { ReactNode } from "react";

export const styles = {
  container: "flex gap-2 items-center",
  label: "text-xs min-w-24 text-end",
  input: "!text-xs",
};

const SERPFormItem = ({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) => {
  return (
    <div className={styles.container}>
      <Label className={styles.label}>{title}</Label>
      {children}
    </div>
  );
};

export default SERPFormItem;
