import CookiesDetails from "./cookies";
import ImageDetails from "./image-details";
import OutlinksDetails from "./outlinks";
import ResourcesDetails from "./resources";
import UrlDetails from "./url-details";

export type tabTypes =
  | "url-details"
  // | "inlinks"
  | "outlinks"
  | "image-details"
  | "cookies"
  | "resources";
// | "serp-snippet";
// | "spelling-and-grammar";

export const tabs = {
  "url-details": {
    title: "URL Details",
    component: (data: any) => <UrlDetails data={data} />,
  },
  // inlinks: {
  //   title: "Inlinks",
  //   component: (data: any) => <></>,
  // },
  outlinks: {
    title: "Outlinks",
    component: (data: any) => <OutlinksDetails data={data} />,
  },
  "image-details": {
    title: "Image Details",
    component: (data: any) => <ImageDetails data={data} />,
  },
  cookies: {
    title: "Cookies",
    component: (data: any) => <CookiesDetails data={data} />,
  },
  resources: {
    title: "Resources",
    component: (data: any) => <ResourcesDetails data={data} />,
  },
  // "serp-snippet": {
  //   title: "SERP Snippet",
  //   component: (data: any) => <SERPSnippet data={data} />,
  // },
};
