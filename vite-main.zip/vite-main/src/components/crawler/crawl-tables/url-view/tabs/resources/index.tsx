import TruncateText from "@/components/common/text-truncater";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const ResourcesDetails = ({ data }: { data: any }) => {
  if (!data) return <>Please, select URL</>;

  return (
    <div className="flex flex-col gap-2">
      <h2 className="text-2xl font-semibold">Resources Details</h2>
      <Table parentClassName="max-h-[300px] border rounded">
        <TableHeader>
          <TableRow>
            <TableHead>URL</TableHead>
            <TableHead>Content Type</TableHead>
            <TableHead>xPath</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data?.static_urls?.map((url: any, i: number) => (
            <TableRow key={i}>
              <TableCell>
                {<TruncateText content={url.url} max={52} /> || "-"}
              </TableCell>
              <TableCell>{url.content_type || "-"}</TableCell>
              <TableCell>{url.xpath || "-"}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default ResourcesDetails;
