export const keysToTake: {
  [key: string]: { title: string; value: (data: any) => string | number };
} = {
  address: {
    title: "Address",
    value: (data: any) => data?.url || "-",
  },
  content_type: {
    title: "Content Type",
    value: (data: any) => data?.url_detail?.content_type || "-",
  },
  status_code: {
    title: "Status Code",
    value: (data: any) => data?.url_detail?.status_code || "-",
  },
  status: {
    title: "Status",
    value: (data: any) => data?.url_detail?.status || "-",
  },
  size: {
    title: "Size",
    value: (data: any) => data?.url_detail?.size?.toFixed(2) || "-",
  },
  indexability: {
    title: "Indexability",
    value: (data: any) =>
      data?.url_detail?.no_index ? "Non-Indexable" : "Indexable",
  },
  indexability_status: {
    title: "Indexability Status",
    value: (data: any) => data?.url_detail?.indexability || "-",
  },
  http_version: {
    title: "HTTP Version",
    value: (data: any) => data?.url_detail?.http_version || "-",
  },
  response_time: {
    title: "Response Time",
    value: (data: any) => data?.url_detail?.response_time || "-",
  },
  title_1: {
    title: "Title 1",
    value: (data: any) => data?.title_detail?.[0]?.title || "-",
  },
  title_1_length: {
    title: "Title 1 Length",
    value: (data: any) => data?.title_detail?.[0]?.length || "-",
  },
  meta_description_1: {
    title: "Meta Description 1",
    value: (data: any) =>
      data?.meta_description_detail?.[0]?.description || "-",
  },
  meta_description_1_length: {
    title: "Meta Description 1 Length",
    value: (data: any) => data?.meta_description_detail?.[0]?.length || "-",
  },
  meta_keyword_1: {
    title: "Meta Keywords 1",
    value: (data: any) => data?.meta_keywords_detail?.[0]?.keyword || "-",
  },
  meta_keywords_1_length: {
    title: "Meta Keywords 1 Length",
    value: (data: any) => data?.meta_keywords_detail?.[0]?.length || "-",
  },
  h1_1: {
    title: "H1-1",
    value: (data: any) => data?.h1_detail?.[0]?.h1 || "-",
  },
  h1_1_length: {
    title: "H1-1 Length",
    value: (data: any) => data?.h1_detail?.[0]?.length || "-",
  },
  word_count: {
    title: "Word Count",
    value: (data: any) => data?.content_detail?.word_count || "-",
  },
  sentence_count: {
    title: "Sentence Count",
    value: (data: any) => data?.content_detail?.sentence_count || "-",
  },
  average_word_per_sentence: {
    title: "Average Word per Sentence",
    value: (data: any) =>
      data?.content_detail?.average_word_per_sentence || "-",
  },
  external_outlinks: {
    title: "External Outlinks",
    value: (data: any) => data?.external_urls?.length || 0,
  },
  // meta_description_2: {
  //   title: "Meta Description 2",
  //   value: (data: any) =>
  //     data?.meta_description_detail?.[1]?.description || "-",
  // },
  // meta_description_2_length: {
  //   title: "Meta Description 2 Length",
  //   value: (data: any) => data?.meta_description_detail?.[1]?.length || "-",
  // },
  // meta_keyword_2: {
  //   title: "Meta Keywords 2",
  //   value: (data: any) => data?.meta_keywords_detail?.[1]?.keyword || "-",
  // },
  // meta_keywords_2_length: {
  //   title: "Meta Keywords 2 Length",
  //   value: (data: any) => data?.meta_keywords_detail?.[1]?.length || "-",
  // },
  // h1_2: {
  //   title: "H1-2",
  //   value: (data: any) => data?.h1_detail?.[1]?.h1 || "-",
  // },
  // h1_2_length: {
  //   title: "H1-2 Length",
  //   value: (data: any) => data?.h1_detail?.[1]?.length || "-",
  // },
  // meta_description_3: {
  //   title: "Meta Description 3",
  //   value: (data: any) =>
  //     data?.meta_description_detail?.[2]?.description || "-",
  // },
  // meta_description_3_length: {
  //   title: "Meta Description 3 Length",
  //   value: (data: any) => data?.meta_description_detail?.[2]?.length || "-",
  // },
  // meta_keyword_3: {
  //   title: "Meta Keywords 3",
  //   value: (data: any) => data?.meta_keywords_detail?.[2]?.keyword || "-",
  // },
  // meta_keywords_3_length: {
  //   title: "Meta Keywords 3 Length",
  //   value: (data: any) => data?.meta_keywords_detail?.[2]?.length || "-",
  // },
  // h1_3: {
  //   title: "H1-3",
  //   value: (data: any) => data?.h1_detail?.[2]?.h1 || "-",
  // },
  // h1_3_length: {
  //   title: "H1-3 Length",
  //   value: (data: any) => data?.h1_detail?.[2]?.length || "-",
  // },
};
