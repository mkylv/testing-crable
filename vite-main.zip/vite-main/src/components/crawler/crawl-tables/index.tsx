import URLs from "./urls";
import Issues from "./issues";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import URLView from "./url-view";
import { useWindowWidth } from "@react-hook/window-size";
import { cn } from "@/lib/utils";
import IssueDetails from "./details";
import CrawlFilters from "./components/crawl-filters";

const CrawlTables = () => {
  const screenWidth = useWindowWidth();

  const mobile = screenWidth <= 768;

  return (
    <section className="flex flex-col gap-6">
      <CrawlFilters />
      <ResizablePanelGroup
        className="flex flex-col gap-6 overflow-x-scroll"
        direction={"vertical"}
      >
        <ResizablePanelGroup
          className="flex gap-4"
          direction={mobile ? "vertical" : "horizontal"}
        >
          <ResizablePanel
            className={cn(mobile && "min-h-[500px]")}
            defaultSize={mobile ? 100 : 50}
          >
            <URLs />
          </ResizablePanel>
          <ResizableHandle withHandle />
          <ResizablePanel
            className={cn(mobile && "min-h-[500px]")}
            defaultSize={mobile ? 100 : 50}
          >
            <Issues />
          </ResizablePanel>
        </ResizablePanelGroup>
        {mobile && <hr />}
        <ResizablePanelGroup
          className="flex gap-4"
          direction={mobile ? "vertical" : "horizontal"}
        >
          <ResizablePanel
            className={cn(mobile && "min-h-[500px]")}
            defaultSize={mobile ? 100 : 50}
          >
            <URLView />
          </ResizablePanel>
          <ResizableHandle withHandle />
          <ResizablePanel
            className={cn(mobile && "min-h-[500px]")}
            defaultSize={mobile ? 100 : 50}
          >
            <IssueDetails />
          </ResizablePanel>
        </ResizablePanelGroup>
      </ResizablePanelGroup>
    </section>
  );
};

export default CrawlTables;
