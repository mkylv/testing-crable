import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { MagnifyingGlass } from "@phosphor-icons/react";

export default function SearchUrl() {
  const { urlSearchQuery, setUrlSearchQuery } = useCrawlerUrlsStore();

  return (
    <form className="flex items-center gap-3">
      <Input
        value={urlSearchQuery}
        onChange={(e) => setUrlSearchQuery(e.target.value)}
        type="search"
        placeholder="Search"
      />
      <Button type="button" className="w-16">
        <MagnifyingGlass />
      </Button>
    </form>
  );
}
