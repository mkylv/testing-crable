import { filterSet } from "../types";
import { canonicalsFilters } from "./canonicals";
import { contentFilters } from "./content";
import { externalUrlsFilters } from "./external-urls";
import { h1Filters } from "./h1";
import { h2Filters } from "./h2";
import { imageFilters } from "./images";
import { internalUrlsFilters } from "./internal-urls";
import { metaDescriptionsFilters } from "./meta-description";
import { metaKeywordFilters } from "./meta-keywords";
import { pageTitlesFilters } from "./page-titles";
import { responseCodesFilters } from "./response-codes";
import { securityUrlsFilter } from "./security";
import { staticFilters } from "./statics";

export const filters: { [key: string]: filterSet } = {
  internals: internalUrlsFilters,
  externals: externalUrlsFilters,
  security: securityUrlsFilter,
  "response-codes": responseCodesFilters,
  "page-titles": pageTitlesFilters,
  "meta-description": metaDescriptionsFilters,
  "meta-keywords": metaKeywordFilters,
  h1: h1Filters,
  h2: h2Filters,
  content: contentFilters,
  images: imageFilters,
  canonicals: canonicalsFilters,
  statics: staticFilters,
};
