import { filterSet } from "../types";

export const metaDescriptionsFilters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  "status-200": {
    title: "Status 200",
    formula: (url) => url.url_detail?.status_code === 200,
  },
  "status-500": {
    title: "Status 500",
    formula: (url) => url.url_detail?.status_code === 500,
  },
  indexable: {
    title: "Indexable",
    formula: (url) => !url.url_detail?.no_index,
  },
  "non-indexable": {
    title: "Non-indexable",
    formula: (url) => url.url_detail?.no_index,
  },
  "with-indexability-status": {
    title: "With indexability status",
    formula: (url) => url.url_detail?.indexability.length,
  },
  "with-description-1": {
    title: "With description 1",
    formula: (url) => url.meta_description_detail?.[0]?.description.length > 1,
  },
  "without-description-1": {
    title: "Without description 1",
    formula: (url) =>
      !(url.meta_description_detail?.[0]?.description.length > 1),
  },
  "with-description-2": {
    title: "With description 2",
    formula: (url) => url.meta_description_detail?.[1]?.description.length > 1,
  },
  "with-description-3": {
    title: "With description 3",
    formula: (url) => url.meta_description_detail?.[2]?.description.length > 1,
  },
};
