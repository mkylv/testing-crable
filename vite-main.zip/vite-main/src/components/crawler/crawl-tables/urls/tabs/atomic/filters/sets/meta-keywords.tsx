import { filterSet } from "../types";

export const metaKeywordFilters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  "status-200": {
    title: "Status 200",
    formula: (url) => url.url_detail?.status_code === 200,
  },
  "status-500": {
    title: "Status 500",
    formula: (url) => url.url_detail?.status_code === 500,
  },
  indexable: {
    title: "Indexable",
    formula: (url) => !url.url_detail?.no_index,
  },
  "non-indexable": {
    title: "Non-indexable",
    formula: (url) => url.url_detail?.no_index,
  },
  "with-indexability-status": {
    title: "With indexability status",
    formula: (url) => url.url_detail?.indexability.length,
  },
  "with-keyword-1": {
    title: "With keyword 1",
    formula: (url) => url.meta_keywords_detail?.[0]?.keyword.length > 1,
  },
  "without-keyword-1": {
    title: "Without keyword 1",
    formula: (url) => !(url.meta_keywords_detail?.[0]?.keyword.length > 1),
  },
  "with-keyword-2": {
    title: "With keyword 2",
    formula: (url) => url.meta_keywords_detail?.[1]?.keyword.length > 1,
  },
  "with-keyword-3": {
    title: "With keyword 3",
    formula: (url) => url.meta_keywords_detail?.[2]?.keyword.length > 1,
  },
};
