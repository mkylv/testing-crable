import { filterSet } from "../types";

export const h1Filters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  "status-200": {
    title: "Status 200",
    formula: (url) => url.url_detail?.status_code === 200,
  },
  "status-500": {
    title: "Status 500",
    formula: (url) => url.url_detail?.status_code === 500,
  },
  indexable: {
    title: "Indexable",
    formula: (url) => !url.url_detail?.no_index,
  },
  "non-indexable": {
    title: "Non-indexable",
    formula: (url) => url.url_detail?.no_index,
  },
  "with-indexability-status": {
    title: "With indexability status",
    formula: (url) => url.url_detail?.indexability.length,
  },
  "with-h1-1": {
    title: "With H1 1",
    formula: (url) => url.h1_detail?.[0]?.h1.length > 1,
  },
  "without-h1-1": {
    title: "Without H1 1",
    formula: (url) => !(url.h1_detail?.[0]?.h1.length > 1),
  },
  "with-h1-2": {
    title: "With H1 2",
    formula: (url) => url.h1_detail?.[1]?.h1.length > 1,
  },
  "with-h1-3": {
    title: "With H1 3",
    formula: (url) => url.h1_detail?.[2]?.h1.length > 1,
  },
};
