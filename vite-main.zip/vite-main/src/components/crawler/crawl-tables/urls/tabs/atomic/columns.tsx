import { useMemo } from "react";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import TruncateText from "@/components/common/text-truncater";
import {
  CheckIndexMenu,
  CopyUrl,
  OpenInNewPage,
} from "@/components/common/crawler/context";

export const useGetColumns = (data: any) => {
  const { setSelectedURL } = useCrawlerUrlsStore();

  const columns = useMemo(
    () => [
      // URL
      {
        accessorKey: "url",
        header: () => <div>URL</div>,
        cell: ({ row }: any) =>
          (
            <ContextMenu>
              <ContextMenuTrigger>
                <button
                  className="text-left"
                  onClick={() => {
                    setSelectedURL(row.original.url || row.original.src);
                  }}
                >
                  <TruncateText
                    className="!text-wrap"
                    max={56}
                    content={row.original.url || row.original.src}
                  />
                </button>
              </ContextMenuTrigger>
              <ContextMenuContent>
                <ContextMenuItem>
                  <OpenInNewPage url={row.original.url || row.original.src} />
                </ContextMenuItem>
                <ContextMenuSeparator />
                <ContextMenuItem>
                  <CopyUrl url={row.original.url || row.original.src} />
                </ContextMenuItem>
                <ContextMenuSeparator />
                <CheckIndexMenu url={row.original.url || row.original.src} />
              </ContextMenuContent>
            </ContextMenu>
          ) || "-",
        size: 450,
      },
      // Content Type
      {
        accessorKey: "url_detail.content_type",
        header: "Content Type",
        cell: ({ row }: any) =>
          row.original.url_detail?.content_type ||
          row.original.url?.split(".").reverse()[0],
      },
      // Status Code
      {
        accessorKey: "url_detail.status_code",
        header: "Status Code",
        cell: ({ row }: any) => row.original.url_detail?.status_code || "-",
      },
      // Status
      {
        accessorKey: "url_detail.status",
        header: "Status",
        cell: ({ row }: any) => row.original.url_detail?.status || "-",
      },
      // HTTP Version
      {
        accessorKey: "url_detail.http_version",
        header: "HTTP Version",
        cell: ({ row }: any) => row.original.url_detail?.http_version || "-",
      },
      // No Index
      {
        accessorKey: "url_detail.no_index",
        header: "Indexability",
        cell: ({ row }: any) =>
          row.original.url_detail?.no_index
            ? "Non-Indexable"
            : "Indexable" || "-",
      },
      // Indexability
      {
        accessorKey: "url_detail.indexability",
        header: "Indexability status",
        cell: ({ row }: any) =>
          row.original.url_detail?.indexability?.join(", ") || "-",
      },
      // X Robots Tag
      {
        accessorKey: "url_detail.x_robots_tag",
        header: () => <span className="text-nowrap">X Robots Tag</span>,
        cell: ({ row }: any) =>
          row.original.url_detail?.["x-robots-tag"] || "-",
      },
      // Response Time
      {
        accessorKey: "url_detail.response_time",
        header: "Response Time",
        cell: ({ row }: any) => row.original.url_detail?.response_time || "-",
      },
      // Length
      {
        accessorKey: "url_detail.length",
        header: "Length",
        cell: ({ row }: any) => row.original.url_detail?.length || "-",
      },
      // Encoded URL
      {
        accessorKey: "url_detail.encoded_url",
        header: "Encoded URL",
        cell: ({ row }: any) =>
          (
            <TruncateText
              max={56}
              content={row.original.url_detail?.encoded_url}
            />
          ) || "-",
        size: 450,
      },
      // Canonical 1
      {
        accessorKey: `link_set.0.canonical`,
        header: () => (
          <span className="text-nowrap">{`Canonical Link Element 1`}</span>
        ),
        cell: () => "-",
      },
      // Canonical 2
      {
        accessorKey: `link_set.1.canonical`,
        header: () => (
          <span className="text-nowrap">{`Canonical Link Element 2`}</span>
        ),
        cell: () => "-",
      },
      // Canonical 3
      {
        accessorKey: `link_set.2.canonical`,
        header: () => (
          <span className="text-nowrap">{`Canonical Link Element 3`}</span>
        ),
        cell: () => "-",
      },
      // Title 1
      {
        accessorKey: `link_set.0.title`,
        header: () => <span className="text-nowrap">{`Title 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.title_detail?.[0]?.title}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Title 1 occurrences
      {
        accessorKey: `link_set.0.title.occurrences`,
        header: () => (
          <span className="text-nowrap">{`Title occurrences 1`}</span>
        ),
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.title_detail?.[0]?.occurrences || 1 || "-"}
          </span>
        ),
      },
      // Title 1 length
      {
        accessorKey: `link_set.0.title.length`,
        header: () => <span className="text-nowrap">{`Title length 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.title_detail?.[0]?.length || 1 || "-"}
          </span>
        ),
      },
      // Title 2
      {
        accessorKey: `link_set.1.title`,
        header: () => <span className="text-nowrap">{`Title 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.title_detail?.[1]?.title}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Title 2 occurrences
      {
        accessorKey: `link_set.1.title.occurrences`,
        header: () => (
          <span className="text-nowrap">{`Title occurrences 2`}</span>
        ),
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.title_detail?.[1]?.occurrences || 1 || "-"}
          </span>
        ),
      },
      // Title 2 length
      {
        accessorKey: `link_set.1.title.length`,
        header: () => <span className="text-nowrap">{`Title length 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.title_detail?.[1]?.length || 1 || "-"}
          </span>
        ),
      },
      // Title 3
      {
        accessorKey: `link_set.2.title`,
        header: () => <span className="text-nowrap">{`Title 3`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.title_detail?.[2]?.title}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Title 3 occurrences
      {
        accessorKey: `link_set.2.title.occurrences`,
        header: () => (
          <span className="text-nowrap">{`Title occurrences 3`}</span>
        ),
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.title_detail?.[2]?.occurrences || 1 || "-"}
          </span>
        ),
      },
      // Title 3 length
      {
        accessorKey: `link_set.2.title.length`,
        header: () => <span className="text-nowrap">{`Title length 3`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.title_detail?.[2]?.length || 1 || "-"}
          </span>
        ),
      },
      // Description 1
      {
        accessorKey: `link_set.0.description`,
        header: () => <span>{`Description 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.meta_description_detail?.[0]?.description}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Description length 1
      {
        accessorKey: `link_set.0.description.length`,
        header: () => (
          <span className="text-nowrap">{`Description length 1`}</span>
        ),
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.meta_description_detail?.[0]?.length || "-"}
          </span>
        ),
      },
      // Description 2
      {
        accessorKey: `link_set.1.description`,
        header: () => <span>{`Description 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.meta_description_detail?.[1]?.description}
              />
            ) || "-"}
          </span>
        ),
      },
      // Description length 2
      {
        accessorKey: `link_set.1.description.length`,
        header: () => (
          <span className="text-nowrap">{`Description length 2`}</span>
        ),
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.meta_description_detail?.[1]?.length || "-"}
          </span>
        ),
      },
      // Description 3
      {
        accessorKey: `link_set.2.description`,
        header: () => <span>{`Description 3`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.meta_description_detail?.[2]?.description}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Description length 3
      {
        accessorKey: `link_set.2.description.length`,
        header: () => (
          <span className="text-nowrap">{`Description length 3`}</span>
        ),
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.meta_description_detail?.[2]?.length || "-"}
          </span>
        ),
        size: 450,
      },
      // Keyword 1
      {
        accessorKey: `link_set.0.keyword`,
        header: () => <span>{`Keyword 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.meta_keywords_detail?.[0]?.keyword}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Keyword length 1
      {
        accessorKey: `link_set.0.keyword.length`,
        header: () => <span>{`Keyword length 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.meta_keywords_detail?.[0]?.length || "-"}
          </span>
        ),
      },
      // Keyword 2
      {
        accessorKey: `link_set.1.keyword`,
        header: () => <span>{`Keyword 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.meta_keywords_detail?.[1]?.keyword}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Keyword length 2
      {
        accessorKey: `link_set.1.keyword.length`,
        header: () => <span>{`Keyword length 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.meta_keywords_detail?.[1]?.length || "-"}
          </span>
        ),
      },
      // Keyword 3
      {
        accessorKey: `link_set.2.keyword`,
        header: () => <span>{`Keyword 3`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.meta_keywords_detail?.[2]?.keyword}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // Keyword length 3
      {
        accessorKey: `link_set.2.keyword.length`,
        header: () => <span>{`Keyword length 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {row.original.meta_keywords_detail?.[2]?.length || "-"}
          </span>
        ),
      },
      // H1 1
      {
        accessorKey: `link_set.0.h1`,
        header: () => <span>{`H1 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.h1_detail?.[0]?.h1}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // H1 length 1
      {
        accessorKey: `link_set.0.h1.length`,
        header: () => <span className="text-nowrap">{`H1 length 1`}</span>,
        cell: ({ row }: any) => {
          return (
            <span className="text-nowrap">
              {row.original.h1_detail?.[0]?.length || "-"}
            </span>
          );
        },
      },
      // H1 2
      {
        accessorKey: `link_set.1.h1`,
        header: () => <span>{`H1 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.h1_detail?.[1]?.h1}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // H1 length 2
      {
        accessorKey: `link_set.1.h1.length`,
        header: () => <span className="text-nowrap">{`H1 length 2`}</span>,
        cell: ({ row }: any) => {
          return (
            <span className="text-nowrap">
              {row.original.h1_detail?.[1]?.length || "-"}
            </span>
          );
        },
      },
      // H1 3
      {
        accessorKey: `link_set.2.h1`,
        header: () => <span>{`H1  3`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.h1_detail?.[2]?.h1}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // H1 length 3
      {
        accessorKey: `link_set.2.h1.length`,
        header: () => <span className="text-nowrap">{`H1 length  3`}</span>,
        cell: ({ row }: any) => {
          return (
            <span className="text-nowrap">
              {row.original.h1_detail?.[2]?.length || "-"}
            </span>
          );
        },
      },
      // H2 1
      {
        accessorKey: `link_set.0.h2`,
        header: () => <span>{`H2 1`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.h2_detail?.[0]?.h2}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // H2 length 1
      {
        accessorKey: `link_set.0.h2.length`,
        header: () => <span className="text-nowrap">{`H2 length 1`}</span>,
        cell: ({ row }: any) => {
          return (
            <span className="text-nowrap">
              {row.original.h2_detail?.[0]?.length || "-"}
            </span>
          );
        },
      },
      // H2 2
      {
        accessorKey: `link_set.1.h2`,
        header: () => <span>{`H2 2`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.h2_detail?.[1]?.h2}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // H2 length 2
      {
        accessorKey: `link_set.1.h2.length`,
        header: () => <span className="text-nowrap">{`H2 length 2`}</span>,
        cell: ({ row }: any) => {
          return (
            <span className="text-nowrap">
              {row.original.h2_detail?.[1]?.length || "-"}
            </span>
          );
        },
      },
      // H2 3
      {
        accessorKey: `link_set.2.h2`,
        header: () => <span>{`H2 3`}</span>,
        cell: ({ row }: any) => (
          <span className="text-nowrap">
            {(
              <TruncateText
                max={56}
                content={row.original.h2_detail?.[2]?.h2}
              />
            ) || "-"}
          </span>
        ),
        size: 450,
      },
      // H2 length 3
      {
        accessorKey: `link_set.2.h2.length`,
        header: () => <span className="text-nowrap">{`H2 length  3`}</span>,
        cell: ({ row }: any) => {
          return (
            <span className="text-nowrap">
              {row.original.h2_detail?.[2]?.length || "-"}
            </span>
          );
        },
      },
      // Word count
      {
        accessorKey: "content_detail.word_count",
        header: "Word Count",
        cell: ({ row }: any) => row.original.content_detail?.word_count || "-",
      },
      // Sentence count
      {
        accessorKey: "content_detail.sentence_count",
        header: "Sentence Count",
        cell: ({ row }: any) =>
          row.original.content_detail?.sentence_count || "-",
      },
      // Average word per sentence
      {
        accessorKey: "content_detail.average_word_per_sentence",
        header: "Average word per sentence",
        cell: ({ row }: any) =>
          row.original.content_detail?.average_word_per_sentence || "-",
      },
      // Image alt
      {
        accessorKey: "image.alt",
        header: "Alt",
        cell: ({ row }: any) => row.original?.alt || "-",
      },
      // Image size
      {
        accessorKey: "image.size",
        header: "Size",
        cell: ({ row }: any) => `${row.original?.size} KB` || "-",
      },
      // xPath
      {
        accessorKey: "image.xpath",
        header: "xPath",
        cell: ({ row }: any) => row.original?.xpath || "-",
        size: 450,
      },
      // Rel Prev
      {
        accessorKey: "canonical.rel_prev",
        header: () => <span className="text-nowrap">rel-prev</span>,
        cell: ({ row }: any) => row.original.rel_prev || "-",
      },
      // Rel Next
      {
        accessorKey: "canonical.rel_next",
        header: () => <span className="text-nowrap">rel-next</span>,
        cell: ({ row }: any) => row.original.rel_next || "-",
      },
    ],
    [setSelectedURL]
  );

  return { columns };
};
