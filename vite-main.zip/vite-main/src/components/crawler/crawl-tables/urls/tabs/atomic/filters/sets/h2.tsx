import { filterSet } from "../types";

export const h2Filters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  "status-200": {
    title: "Status 200",
    formula: (url) => url.url_detail?.status_code === 200,
  },
  "status-500": {
    title: "Status 500",
    formula: (url) => url.url_detail?.status_code === 500,
  },
  indexable: {
    title: "Indexable",
    formula: (url) => !url.url_detail?.no_index,
  },
  "non-indexable": {
    title: "Non-indexable",
    formula: (url) => url.url_detail?.no_index,
  },
  "with-indexability-status": {
    title: "With indexability status",
    formula: (url) => url.url_detail?.indexability.length,
  },
  "with-h2-1": {
    title: "With H2 1",
    formula: (url) => url.h2_detail?.[0]?.h2.length > 1,
  },
  "without-h2-1": {
    title: "Without H2 1",
    formula: (url) => !(url.h2_detail?.[0]?.h2.length > 1),
  },
  "with-h2-2": {
    title: "With H2 2",
    formula: (url) => url.h2_detail?.[1]?.h2.length > 1,
  },
  "with-h2-3": {
    title: "With H2 3",
    formula: (url) => url.h2_detail?.[2]?.h2.length > 1,
  },
};
