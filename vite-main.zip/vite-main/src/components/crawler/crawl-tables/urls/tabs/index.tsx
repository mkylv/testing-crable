export type tabTypes =
  | "internals"
  | "externals"
  | "page-titles"
  | "meta-description"
  | "meta-keywords"
  | "h1"
  | "h2"
  | "content"
  | "images";

export const tabs = {
  internals: {
    title: "Internals",
  },
  externals: {
    title: "Externals",
  },
  security: {
    title: "Security",
  },
  "response-codes": {
    title: "Response Codes",
  },
  "page-titles": {
    title: "Page Titles",
  },
  "meta-description": {
    title: "Meta Description",
  },
  "meta-keywords": {
    title: "Meta Keywords",
  },
  h1: {
    title: "H1",
  },
  h2: {
    title: "H2",
  },
  content: {
    title: "Content",
  },
  images: {
    title: "Images",
  },
  canonicals: {
    title: "Canonicals",
  },
  statics: {
    title: "Statics",
  },
};
