import { filterSet } from "../types";

export const staticFilters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  js: {
    title: "JavaScript",
    formula: (url) => url.url.split(".").reverse()[0] === "js",
  },
  css: {
    title: "CSS",
    formula: (url) => url.url.split(".").reverse()[0] === "css",
  },
};
