import { filterSet } from "../types";

export const canonicalsFilters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  "status-200": {
    title: "Status 200",
    formula: (url) => url.url_detail?.status_code === 200,
  },
  "status-500": {
    title: "Status 500",
    formula: (url) => url.url_detail?.status_code === 500,
  },
  indexable: {
    title: "Indexable",
    formula: (url) => !url.url_detail?.no_index,
  },
  "non-indexable": {
    title: "Non-indexable",
    formula: (url) => url.url_detail?.no_index,
  },
  "with-indexability-status": {
    title: "With indexability status",
    formula: (url) => url.url_detail?.indexability.length,
  },
  "without-rel-next": {
    title: "With rel next",
    formula: (url) => url?.rel_next,
  },
  "with-rel-prev": {
    title: "With rel prev",
    formula: (url) => url?.rel_prev,
  },
};
