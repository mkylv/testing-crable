import {
  ColumnDef,
  ColumnFiltersState,
  SortingState,
  flexRender,
  VisibilityState,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
  ColumnSizingState,
  Row,
  Column,
} from "@tanstack/react-table";

import {
  forwardRef,
  memo,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react";
import { columnDefinitions } from "./definitions";
import { ColumnResizer } from "@/components/ui/column-resizer";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { useVirtualizer } from "@tanstack/react-virtual";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { tabs, tabTypes } from "..";
import useCrawlFilters from "@/hooks/use-filter.hook";

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
}

export function DataTableInner<TData, TValue>(
  props: DataTableProps<TData, TValue>,
  ref: React.Ref<any>
) {
  const { columns, data } = props;

  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [colSizing, setColSizing] = useState<ColumnSizingState>({});

  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});

  const { urlSearchQuery, selectedUrlTab: currentSelectedUrlTab } =
    useCrawlerUrlsStore();

  const { filterExists } = useCrawlFilters();

  const table = useReactTable({
    data,
    columns,
    defaultColumn: {
      size: 200,
      minSize: 50,
      maxSize: 500,
    },
    columnResizeDirection: "rtl",
    getCoreRowModel: getCoreRowModel(),
    onSortingChange: setSorting,
    enableColumnResizing: true,
    columnResizeMode: "onChange",
    getSortedRowModel: getSortedRowModel(),
    onColumnFiltersChange: setColumnFilters,
    getFilteredRowModel: getFilteredRowModel(),
    onColumnSizingChange: setColSizing,
    onColumnVisibilityChange: setColumnVisibility,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      columnSizing: colSizing,
    },
  });

  useEffect(() => {
    table.getAllColumns().map((column) => {
      const allowedColumns = columnDefinitions[currentSelectedUrlTab];

      // @ts-expect-error - accessorKey is not defined in ColumnDef
      const accessorKey = column.columnDef.accessorKey;

      if (
        !allowedColumns.includes("*") &&
        !allowedColumns.includes(accessorKey)
      ) {
        return column.toggleVisibility(false);
      } else {
        return column.toggleVisibility(true);
      }
    });
  }, [currentSelectedUrlTab, table]);

  useEffect(() => {
    console.log("running");
    table.getColumn("url")?.setFilterValue(urlSearchQuery);
  }, [table, urlSearchQuery]);

  useImperativeHandle(ref, () => ({
    table,
  }));

  const { rows } = table.getRowModel();

  const tableContainerRef = useRef<HTMLDivElement>(null);

  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    estimateSize: () => 37, //estimate row height for accurate scrollbar dragging
    getScrollElement: () => tableContainerRef.current,
    //measure dynamic row height, except in firefox because it measures table border height incorrectly
    measureElement:
      typeof window !== "undefined" &&
      navigator.userAgent.indexOf("Firefox") === -1
        ? (element) => element?.getBoundingClientRect().height
        : undefined,
    overscan: 4,
  });

  return (
    <>
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">
          {tabs[currentSelectedUrlTab as tabTypes].title}
        </h2>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="ml-auto">
              Columns
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            className="max-h-[250px] overflow-y-scroll"
            align="start"
            side="right"
          >
            {table
              .getAllColumns()
              .filter((column: any) => column.getCanHide())
              .filter((column: any) => {
                const definitions = columnDefinitions[currentSelectedUrlTab];

                if (definitions.includes("*")) return true;
                else return definitions.includes(column.columnDef.accessorKey);
              })
              .map((column: Column<any>) => {
                return (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={column.getIsVisible()}
                    onCheckedChange={(value) => column.toggleVisibility(value)}
                  >
                    {column.id
                      .split("_")
                      .join(".")
                      .split(".")
                      .map((word) =>
                        !isNaN(parseInt(word))
                          ? parseInt(word) + 1
                          : word.charAt(0).toUpperCase() + word.slice(1)
                      )
                      .join(" ")}
                  </DropdownMenuCheckboxItem>
                );
              })}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div
        ref={tableContainerRef}
        className={cn(
          "overscroll-none rounded-md border border-secondary relative overflow-auto",
          filterExists ? "h-[175px]" : "h-[200px]"
        )}
      >
        <table
          className={cn(
            "grid w-full caption-bottom text-sm",
            filterExists ? "h-[185px]" : "h-[200px]"
          )}
        >
          <thead className="grid sticky top-0 z-[1] bg-muted p-3 h-min">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id} className="flex w-full">
                {headerGroup.headers.map((header: any) => {
                  return (
                    <th
                      colSpan={header.colSpan}
                      key={header.id}
                      style={{
                        display: "flex",
                        width: `${header.getSize()}px`,
                      }}
                    >
                      {flexRender(
                        header.column.columnDef.header,
                        header.getContext()
                      )}
                      <ColumnResizer header={header} />
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>
          <tbody
            className="grid relative"
            style={{
              height: `${rowVirtualizer.getTotalSize()}px`, //tells scrollbar how big the table is
            }}
          >
            {rowVirtualizer.getVirtualItems().length > 0 ? (
              rowVirtualizer.getVirtualItems().map((virtualRow) => {
                const row = rows[virtualRow.index] as Row<any>;
                return (
                  <tr
                    data-index={virtualRow.index} //needed for dynamic row height measurement
                    ref={(node) => rowVirtualizer.measureElement(node)} //measure dynamic row height
                    key={row.id}
                    className="flex absolute w-full p-3 border-b"
                    style={{
                      transform: `translateY(${virtualRow.start}px)`, //this should always be a `style` as it changes on scroll
                    }}
                  >
                    {row.getVisibleCells().map((cell) => {
                      return (
                        <td
                          key={cell.id}
                          className="flex "
                          style={{
                            width: cell.column.getSize(),
                          }}
                        >
                          {flexRender(
                            cell.column.columnDef.cell,
                            cell.getContext()
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })
            ) : (
              <tr className="px-3">
                <td>No results.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </>
  );
}

export const DataTable = memo(forwardRef(DataTableInner));
