export type filterSet = {
  [key: string]: {
    formula: (url: any) => void;
    title: string;
    withDivider?: boolean;
  };
};
