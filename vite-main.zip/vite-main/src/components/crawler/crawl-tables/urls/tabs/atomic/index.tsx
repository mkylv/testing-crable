import { useGetColumns } from "./columns";
import { DataTable } from "./table";
// import { DataTable } from "./virtualized-table";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { useMemo, useRef } from "react";
import { CrawlFilter } from "@/lib/crawler/filter";
import { filters } from "./filters/sets";

const AtomicCrawlTable = () => {
  const { batchedCrawlData: _crawlData } = useCrawlerDataStore();

  const { selectedIssueBatch } = useCrawlerUrlsStore();

  const {
    selectedResponseTime,
    currentUrlFilter,
    selectedUrlTab: currentSelectedUrlTab,
  } = useCrawlerUrlsStore();

  const table = useRef<any>(null);

  let crawlData = useMemo(() => _crawlData, [_crawlData]);

  // Filter data for the selected tab
  if (
    currentSelectedUrlTab === "internals" ||
    currentSelectedUrlTab === "security" ||
    currentSelectedUrlTab === "response-codes" ||
    currentSelectedUrlTab === "page-titles" ||
    currentSelectedUrlTab === "meta-description" ||
    currentSelectedUrlTab === "meta-keywords" ||
    currentSelectedUrlTab === "h1" ||
    currentSelectedUrlTab === "h2" ||
    currentSelectedUrlTab === "content"
  ) {
    crawlData = CrawlFilter.filter(crawlData, {
      key: "type",
      value: "page_detail",
    });
  } else if (currentSelectedUrlTab === "externals") {
    crawlData = CrawlFilter.filter(crawlData, {
      key: "type",
      value: "external",
    });
  } else if (currentSelectedUrlTab === "images") {
    crawlData = CrawlFilter.filter(crawlData, {
      key: "type",
      value: "image",
    });
  } else if (currentSelectedUrlTab === "canonicals") {
    crawlData = CrawlFilter.filter(crawlData, {
      key: "type",
      value: "canonical",
    });
  } else if (currentSelectedUrlTab === "statics") {
    crawlData = CrawlFilter.filter(crawlData, {
      key: "type",
      value: "static",
    });
  }

  const chosenFilter = useMemo(
    () =>
      filters[currentSelectedUrlTab]
        ? filters[currentSelectedUrlTab][currentUrlFilter]
        : null,
    [currentUrlFilter, currentSelectedUrlTab]
  );

  // Filter data for the current filter
  if (currentUrlFilter !== "all") {
    crawlData = crawlData.filter((data) => chosenFilter?.formula(data));
  }

  // Filter data for the current issue batch
  if (selectedIssueBatch)
    crawlData = crawlData.filter(
      (data) =>
        data.issues &&
        data.issues.some((issue: any) => issue.title === selectedIssueBatch)
    );

  // Filter data for the current response time
  if (selectedResponseTime !== "all")
    crawlData = crawlData.filter((data) => {
      return (
        Math.ceil(data.url_detail?.response_time || -1) === selectedResponseTime
      );
    });

  const { columns } = useGetColumns(crawlData);

  return (
    <div className="flex flex-col gap-2">
      <DataTable columns={columns} data={crawlData} ref={table} />
      <div className="flex justify-end">Total: {crawlData.length}</div>
    </div>
  );
};

export default AtomicCrawlTable;
