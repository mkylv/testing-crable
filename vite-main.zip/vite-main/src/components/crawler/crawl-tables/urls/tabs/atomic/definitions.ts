const indexability = ["url_detail.no_index", "url_detail.indexability"];
const status = ["url_detail.status_code", "url_detail.status"];

const image = ["image.alt", "image.size", "image.xpath"];

const canonical = ["canonical.rel_prev", "canonical.rel_next"];

const title = [
  "link_set.0.title",
  "link_set.0.title.occurrences",
  "link_set.0.title.length",
  "link_set.1.title",
  "link_set.1.title.occurrences",
  "link_set.1.title.length",
  "link_set.2.title",
  "link_set.2.title.occurrences",
  "link_set.2.title.length",
];

const description = [
  "link_set.0.description",
  "link_set.0.description.length",
  "link_set.1.description",
  "link_set.1.description.length",
  "link_set.2.description",
  "link_set.2.description.length",
];

const keywords = [
  "link_set.0.keyword",
  "link_set.0.keyword.length",
  "link_set.1.keyword",
  "link_set.1.keyword.length",
  "link_set.2.keyword",
  "link_set.2.keyword.length",
];

const h1 = [
  "link_set.0.h1",
  "link_set.0.h1.length",
  "link_set.1.h1",
  "link_set.1.h1.length",
  "link_set.2.h1",
  "link_set.2.h1.length",
];

const h2 = [
  "link_set.0.h2",
  "link_set.0.h2.length",
  "link_set.1.h2",
  "link_set.1.h2.length",
  "link_set.2.h2",
  "link_set.2.h2.length",
];

const content = [
  "content_detail.word_count",
  "content_detail.sentence_count",
  "content_detail.average_word_per_sentence",
];

const defaultDefinitions = [
  "url",
  "url_detail.content_type",
  ...status,
  ...indexability,
];

const all = [
  ...defaultDefinitions,
  ...image,
  ...canonical,
  ...title,
  ...description,
  ...keywords,
  ...h1,
  ...h2,
  ...content,
];

export const columnDefinitions: { [key: string]: string[] } = {
  internals: [
    ...all
      .filter((definition) => !canonical.includes(definition))
      .filter((definition) => !image.includes(definition)),
  ],
  externals: [...defaultDefinitions],
  security: [
    ...defaultDefinitions,
    "url_detail.http_version",
    "url_detail.x_robots_tag",
    "link_set.canonical",
  ],
  "response-codes": [...defaultDefinitions, "url_detail.response_time"],
  "page-titles": ["url", ...title, ...indexability],
  "meta-description": ["url", ...description, ...indexability],
  "meta-keywords": ["url", ...keywords, ...indexability],
  h1: ["url", ...h1, ...indexability],
  h2: ["url", ...h2, ...indexability],
  content: ["url", ...content, ...indexability],
  images: [
    "url",
    // "url_detail.content_type",
    ...image,
    // ...indexability,
  ],
  canonicals: [...defaultDefinitions, ...canonical],
  statics: ["url", "url_detail.content_type"],
};
