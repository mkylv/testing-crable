import { filterSet } from "../types";

export const pageTitlesFilters: filterSet = {
  all: {
    title: "All",
    withDivider: true,
    formula: (url) => url,
  },
  "status-200": {
    title: "Status 200",
    formula: (url) => url.url_detail?.status_code === 200,
  },
  "status-500": {
    title: "Status 500",
    formula: (url) => url.url_detail?.status_code === 500,
  },
  indexable: {
    title: "Indexable",
    formula: (url) => !url.url_detail?.no_index,
  },
  "non-indexable": {
    title: "Non-indexable",
    formula: (url) => url.url_detail?.no_index,
  },
  "with-indexability-status": {
    title: "With indexability status",
    formula: (url) => url.url_detail?.indexability.length,
  },
  "with-title-1": {
    title: "With title 1",
    formula: (url) => url.title_detail?.[0]?.title.length > 1,
  },
  "without-title-1": {
    title: "Without title 1",
    formula: (url) => !(url.title_detail?.[0]?.title.length > 1),
  },
  "with-title-2": {
    title: "With title 2",
    formula: (url) => url.title_detail?.[1]?.title.length > 1,
  },
  "with-title-3": {
    title: "With title 3",
    formula: (url) => url.title_detail?.[2]?.title.length > 1,
  },
};
