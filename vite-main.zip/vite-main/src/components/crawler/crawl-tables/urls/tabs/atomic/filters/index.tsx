import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ArrowDown } from "lucide-react";
import { Check, Funnel } from "@phosphor-icons/react";
import { cn } from "@/lib/utils";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { filters } from "./sets";
import { Fragment, useMemo } from "react";

const UrlsFilter = () => {
  const {
    selectedUrlTab,
    currentUrlFilter,
    setUrlFilter: setCurrentUrlFilter,
  } = useCrawlerUrlsStore();

  const chosenFilter = useMemo(
    () =>
      filters[selectedUrlTab]
        ? filters[selectedUrlTab][currentUrlFilter]
        : null,
    [currentUrlFilter, selectedUrlTab]
  );

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant={"secondary"}
          className="flex gap-2 items-center max-w-[230px] w-full"
        >
          <Funnel className="w-4 h-4" /> {chosenFilter?.title}{" "}
          <ArrowDown fontWeight={1000} className="w-3 h-3" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="max-w-[280px] flex flex-col gap-2">
        {filters[selectedUrlTab] ? (
          Object.keys(filters[selectedUrlTab]).map((_filter) => {
            const filter = filters[selectedUrlTab]
              ? filters[selectedUrlTab][_filter]
              : null;

            if (filter)
              return (
                <Fragment key={_filter}>
                  <button
                    onClick={() => setCurrentUrlFilter(_filter)}
                    className={cn("rounded-lg flex gap-2 items-center")}
                  >
                    <div className="w-6 h-6 rounded-full border flex justify-center items-center">
                      {currentUrlFilter === _filter && (
                        <Check className="w-4 h-4" />
                      )}
                    </div>
                    <span className="text-sm font-medium">{filter.title}</span>
                  </button>
                  {filter.withDivider && <hr />}
                </Fragment>
              );
          })
        ) : (
          <>Filter set is not defined for this tab</>
        )}
      </PopoverContent>
    </Popover>
  );
};

export default UrlsFilter;
