import CrawlItemLayout from "../layout";
import { tabs } from "./tabs";

import AtomicCrawlTable from "./tabs/atomic";
import UrlsFilter from "./tabs/atomic/filters";
import RenderTabs from "@/components/common/crawler/tab-renderer";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import CrawlFilters from "../components/crawl-filters";
import SearchUrl from "./components/search";

const URLs = () => {
  const { selectedUrlTab: tab, setSelectedUrlTab: setTab } =
    useCrawlerUrlsStore();

  return (
    <CrawlItemLayout>
      <div className="flex flex-col gap-2 w-full">
        <RenderTabs
          tabs={tabs}
          states={{
            currentSelected: tab,
            setCurrentSelected: setTab,
          }}
        />
        <div className="flex justify-between">
          <div className="flex gap-3">
            <UrlsFilter />
            {/* <div className="flex gap-1">
              <Button variant={"outline"}>
                <ListBullets />
              </Button>
              <Button variant={"secondary"}>
                <TreeView />
              </Button>
            </div> */}
          </div>
        </div>
        <CrawlFilters />
      </div>
      <SearchUrl />
      <AtomicCrawlTable />
    </CrawlItemLayout>
  );
};

export default URLs;
