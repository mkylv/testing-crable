import HowToSolve from "./issues";
import OverviewDetails from "./overview";

import ResponseTimes from "./response-times";

export type viewTypes = "issues" | "response-times";

export const views = {
  issues: {
    title: "Issue Detail",
    component: <HowToSolve />,
  },
  "response-times": {
    title: "Response Times",
    component: <ResponseTimes />,
  },
  overview: {
    title: "Overview",
    component: <OverviewDetails />,
  },
};
