import { useToast } from "@/components/ui/use-toast";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";
import { Copy } from "@phosphor-icons/react";

const IssueDetails = () => {
  const { toast } = useToast();

  const { issues } = useCrawlerDataStore();

  const { selectedIssueBatch } = useCrawlerUrlsStore();

  const foundIssue = issues.find((issue) => issue.title === selectedIssueBatch);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-between">
        {foundIssue ? (
          <button
            onClick={() => {
              if (foundIssue && foundIssue.howToSolve) {
                navigator.clipboard.writeText(foundIssue.howToSolve);
                toast({
                  title: "Copied!",
                });
              }
            }}
            className="flex gap-2 items-center"
          >
            <Copy /> <span className="font-medium">Copy</span>
          </button>
        ) : (
          <div className="w-[63px]" />
        )}
        <h2 className="text-xl font-semibold">Issue Details</h2>
        {/* <div className="flex gap-2 items-center">
            View:
            <Select
              value={selectedIssueDetailView}
              onValueChange={(value) => setSelectedIssueDetailView(value)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.keys(views).map((view) => (
                  <SelectItem key={view} value={view}>
                    {views[view as viewTypes].title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div> */}
        <div className="w-[63px]" />
      </div>
      {foundIssue ? (
        <>
          <div className="flex flex-col gap-1">
            <h3 className="text-lg font-medium">Description</h3>
            <p className="p-4 rounded-lg bg-secondary">
              {foundIssue.description}
            </p>
          </div>
          <div className="flex flex-col gap-1">
            <h3 className="text-lg font-medium">How to fix</h3>
            <p className="p-4 rounded-lg bg-secondary">
              {foundIssue.howToSolve}
            </p>
          </div>
        </>
      ) : (
        <>Select issue to view details</>
      )}
    </div>
  );
};

export default IssueDetails;
