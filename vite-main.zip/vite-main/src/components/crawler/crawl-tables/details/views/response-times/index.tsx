import React, { useEffect, useState } from "react";
import { batchResponseTimes } from "@/lib/crawler";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { useMemo } from "react";
import RenderAreaChart from "./chart";
import { Bar } from "recharts";

const ResponseTimes = () => {
  const { batchedCrawlData } = useCrawlerDataStore();

  const responseTimes = useMemo(() => {
    const formattedData: any[] = [
      {
        interval: "0 - 1",
        total: 0,
      },
      {
        interval: "1 - 2",
        total: 0,
      },
      {
        interval: "2 - 3",
        total: 0,
      },
      {
        interval: "3 - 4",
        total: 0,
      },
      {
        interval: "4 - 5",
        total: 0,
      },
      {
        interval: "5 - 6",
        total: 0,
      },
      {
        interval: "6 - 7",
        total: 0,
      },
      {
        interval: "7 - 8",
        total: 0,
      },
      {
        interval: "8 - 9",
        total: 0,
      },
      {
        interval: "9 - 10",
        total: 0,
      },
      {
        interval: "10+",
        total: 0,
      },
    ];

    const batchedData = batchResponseTimes(batchedCrawlData).sort(
      (a, b) => a.ceil - b.ceil
    );

    batchedData.map((item) => {
      if (item.ceil >= 10) {
        formattedData.find((d) => d.interval === "10+").total +=
          item.urls.length;
      } else {
        formattedData.find(
          (d) => d.interval === `${item.ceil - 1} - ${item.ceil}`
        ).total += item.urls.length;
      }
    });

    return formattedData;
  }, [batchedCrawlData]);

  const bars = [
    {
      dataKey: "0 - 1",
    },
    {
      dataKey: "1 - 2",
    },
    {
      dataKey: "2 - 3",
    },
    {
      dataKey: "3 - 4",
    },
    {
      dataKey: "4 - 5",
    },
    {
      dataKey: "5 - 6",
    },
    {
      dataKey: "6 - 7",
    },
    {
      dataKey: "7 - 8",
    },
    {
      dataKey: "8 - 9",
    },
    {
      dataKey: "9 - 10",
    },
    {
      dataKey: "10+",
    },
  ];

  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-between">
        <div />
        <h2 className="text-2xl font-semibold">Response Times</h2>
        <div />
      </div>
      <div className="flex justify-center mr-12 h-full">
        <RenderAreaChart data={responseTimes} />
      </div>
    </div>
  );
};

export default ResponseTimes;
