import { Column } from "@ant-design/plots";

const RenderAreaChart = ({ data }: { data: any }) => {
  const config = {
    tooltip: {
      title: "Total",
      shared: true,
      showMarkers: false,
      customItems: (items: any[]) => {
        return items.map((item) => ({
          ...item,
          name: item.data.name,
          value: item.data.total,
        }));
      },
    },
    color: "#FF7033",
    data,
    height: 400,
    xField: "name",
    yField: "total",
    columnStyle: {
      fill: "#FF7033",
      maxColumnWidth: 50,
    },
  };

  return <Column {...config} />;
};

export default RenderAreaChart;
