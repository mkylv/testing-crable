import React, { useMemo } from "react";
import RenderAreaChart from "./chart";
import { useCrawlerDataStore } from "@/stores/crawler/data.store";
import { CrawlFilter } from "@/lib/crawler/filter";

const OverviewDetails = () => {
  const { batchedCrawlData } = useCrawlerDataStore();

  const overviewSummary = useMemo(
    () => [
      {
        name: "Total URLs",
        total: batchedCrawlData.length,
      },
      {
        name: "Internals",
        total: CrawlFilter.filter(batchedCrawlData, {
          key: "type",
          value: "page_detail",
        }).length,
      },
      {
        name: "Externals",
        total: CrawlFilter.filter(batchedCrawlData, {
          key: "type",
          value: "external",
        }).length,
      },
      {
        name: "Images",
        total: CrawlFilter.filter(batchedCrawlData, {
          key: "type",
          value: "image",
        }).length,
      },
      {
        name: "Canonicals",
        total: CrawlFilter.filter(batchedCrawlData, {
          key: "type",
          value: "canonical",
        }).length,
      },
      {
        name: "Statics",
        total: CrawlFilter.filter(batchedCrawlData, {
          key: "type",
          value: "static",
        }).length,
      },
    ],
    [batchedCrawlData]
  );

  return (
    <div className="flex flex-col gap-3">
      <div className="flex justify-between">
        <div />
        <h2 className="text-2xl font-semibold">Overview</h2>
        <div />
      </div>
      <div className="flex justify-center mr-12 h-full">
        <RenderAreaChart data={overviewSummary} />
      </div>
    </div>
  );
};

export default OverviewDetails;
