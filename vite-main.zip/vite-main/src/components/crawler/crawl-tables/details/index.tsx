import CrawlItemLayout from "../layout";
import { views, viewTypes } from "./views";
import { useCrawlerUrlsStore } from "@/stores/crawler/urls.store";

const IssueDetails = () => {
  const { selectedIssueTab } = useCrawlerUrlsStore();

  return (
    <CrawlItemLayout>
      {views[selectedIssueTab as viewTypes]?.component || "No view found"}
    </CrawlItemLayout>
  );
};

export default IssueDetails;
