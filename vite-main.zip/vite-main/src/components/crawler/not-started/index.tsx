import { useTheme } from "next-themes";

const CrawlNotStarted = () => {
  const { theme } = useTheme();

  return (
    <div className="relative flex flex-col gap-1">
      <img
        className="w-[200px] h-[200px] lg:mx-[200px] md:mx-[100px] mx-[50px]"
        src={`/crawler/arrow-${theme}.svg`}
        alt="Arrow"
      />
      <div className="text-card-foreground text-center absolute top-[110%] lg:left-[220px] md:left-[110px] left-[55px] text-xl text-balance !select-none font-light">
        Paste the URL of the site you want to analyze <br />
        here.
      </div>
    </div>
  );
};

export default CrawlNotStarted;
