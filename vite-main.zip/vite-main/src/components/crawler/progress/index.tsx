import { useWindowWidth } from "@react-hook/window-size";
import {
  CustomProgressProcessing,
  CustomRadialProgress,
  CustomRadialProgressProcessing,
} from "../../ui/progress";

const CrawlProgress = () => {
  const screenWidth = useWindowWidth();

  const mobile = screenWidth <= 768;

  return mobile ? (
    <CustomProgressProcessing />
  ) : (
    <CustomRadialProgressProcessing />
  );
};

export default CrawlProgress;
