import { ArrowClockwise } from "@phosphor-icons/react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";
import { REGEXP_ONLY_DIGITS_AND_CHARS } from "input-otp";
import { useForm } from "react-hook-form";
import { ConfirmAccountSchema, TConfirmAccount } from "./utils";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { useState } from "react";
import { useUserStore } from "@/stores/user.store";
import {
  useResendAccountVerification,
  useVerifyAccount,
} from "@/api/user/hook";
import { useQueryClient } from "@tanstack/react-query";

const ConfirmEmailModal = () => {
  const queryClient = useQueryClient();

  const { user } = useUserStore();

  const { mutateAsync: processVerification, isPending: isVerificationPending } =
    useVerifyAccount();
  const { mutateAsync: sendVerification, isPending: isRequestPending } =
    useResendAccountVerification();

  const { toast } = useToast();

  const methods = useForm<TConfirmAccount>({
    resolver: zodResolver(ConfirmAccountSchema),
    defaultValues: {
      key: "",
    },
  });

  const handleVerification = async (data: TConfirmAccount) => {
    try {
      const res = await processVerification({
        otp: data.key,
      });

      if (!res.ok)
        return toast({
          title: "Error occurred",
          description: res.message,
          variant: "destructive",
        });

      queryClient.invalidateQueries({
        queryKey: ["user"],
      });

      return toast({
        title: "Verification completed",
      });
    } catch (e: any) {
      const res = JSON.parse(e.request.responseText);

      return toast({
        title: "Error occurred",
        description: res.message,
        variant: "destructive",
      });
    }
  };

  const requestConfirmation = async () => {
    try {
      const res =
        user &&
        (await sendVerification({
          email: user.email,
        }));

      if (!res.ok)
        return toast({
          title: "Error occurred",
          description: res.message,
          variant: "destructive",
        });

      queryClient.invalidateQueries({
        queryKey: ["user"],
      });

      return toast({
        title: "OTP Sent",
        description: "Check your email for the confirmation code",
      });
    } catch (e: any) {
      const res = JSON.parse(e.request.responseText);

      return toast({
        title: "Error occurred",
        description: res.message,
        variant: "destructive",
      });
    }
  };

  return (
    <section className="flex flex-col gap-4 items-center">
      <header className="max-w-[450px] flex flex-col gap-2.5 items-center">
        <h1 className="text-xl">Verify your email to continue</h1>
        <p className="text-center text-secondary-foreground">
          Check your email{" "}
          <span className="font-medium text-foreground">({user?.email})</span>{" "}
          and enter the confirmation code to verify your account
        </p>
      </header>
      <Form {...methods}>
        <section>
          <form
            className="flex flex-col gap-5"
            onSubmit={methods.handleSubmit(handleVerification)}
          >
            <div className="flex flex-col items-center gap-5">
              <FormField
                control={methods.control}
                name="key"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <InputOTP
                        {...field}
                        maxLength={6}
                        pattern={REGEXP_ONLY_DIGITS_AND_CHARS}
                      >
                        <InputOTPGroup>
                          <InputOTPSlot className="text-xl" index={0} />
                          <InputOTPSlot className="text-xl" index={1} />
                          <InputOTPSlot className="text-xl" index={2} />
                          <InputOTPSlot className="text-xl" index={3} />
                          <InputOTPSlot className="text-xl" index={4} />
                          <InputOTPSlot className="text-xl" index={5} />
                        </InputOTPGroup>
                      </InputOTP>
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            <footer className="flex gap-3">
              <Button
                onClick={() => requestConfirmation()}
                disabled={isVerificationPending || isRequestPending}
                type="button"
                className="flex gap-2 items-center"
                variant={"outline"}
              >
                <ArrowClockwise weight="bold" className="w-5 h-5" /> Resend
                confirmation
              </Button>
              <Button
                type="submit"
                disabled={isVerificationPending || isRequestPending}
              >
                Confirm
              </Button>
            </footer>
          </form>
        </section>
      </Form>
    </section>
  );
};

export default ConfirmEmailModal;
