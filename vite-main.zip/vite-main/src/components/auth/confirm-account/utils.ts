import { z } from "zod";

export const ConfirmAccountSchema = z.object({
  key: z.string().min(6, {
    message: "Your one-time password must be 6 characters.",
  }),
});

export type TConfirmAccount = z.infer<typeof ConfirmAccountSchema>;
