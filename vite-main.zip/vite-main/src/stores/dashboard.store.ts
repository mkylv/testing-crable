import { create } from "zustand";

interface CrawlerStore {
  customizeMode: boolean;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (isOpen: boolean) => void;
  setCustomizeMode: (mode: boolean) => void;
}

export const useDashboardStore = create<CrawlerStore>((set) => ({
  customizeMode: false,
  isSidebarOpen: false,
  setCustomizeMode: (mode) =>
    set((state) => ({ ...state, customizeMode: mode })),
  setIsSidebarOpen: (isOpen) =>
    set((state) => ({ ...state, isSidebarOpen: isOpen })),
}));
