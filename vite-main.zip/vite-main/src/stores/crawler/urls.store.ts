import { create } from "zustand";

interface CrawlerUrlsStore {
  urlSearchQuery: string;
  setUrlSearchQuery: (query: string) => void;

  // Top left - URL tabs
  currentUrlFilter: string;
  setUrlFilter: (filter: string) => void;

  // Top left - Bottom left - URL Tabs & view
  selectedURL: string;
  setSelectedURL: (URL: string) => void;

  // Top left - URL tabs
  selectedUrlTab: string;
  setSelectedUrlTab: (tab: string) => void;

  // ------------------------------

  // Bottom left - URL view
  selectedUrlViewTab: string;
  setSelectedUrlViewTab: (tab: string) => void;

  // ------------------------------

  // Top right - URL view
  selectedIssueTab: string;
  setSelectedIssueTab: (tab: string) => void;

  // ------------------------------

  // Top right - issues
  selectedIssueBatch: string;
  setSelectedIssueBatch: (batch: string) => void;

  // ------------------------------

  // Bottom right - issue view
  selectedIssueDetailView: string;
  setSelectedIssueDetailView: (format: string) => void;

  // Top right - response times
  selectedResponseTime: number | string;
  setSelectedResponseTime: (time: number | string) => void;

  //

  reset: () => void;
}

const initialStates = {
  currentUrlFilter: "all",
  selectedURL: "",
  selectedUrlTab: "internals",
  selectedUrlViewTab: "url-details",
  selectedIssueTab: "overview",
  selectedIssueBatch: "",
  selectedIssueDetailView: "how-to-solve",
  selectedResponseTime: "all",
  urlSearchQuery: "",
};

export const useCrawlerUrlsStore = create<CrawlerUrlsStore>((set) => ({
  ...initialStates,

  setUrlFilter: (filter: string) => set({ currentUrlFilter: filter }),

  // ------------------------------

  setSelectedURL: (url: string) => set({ selectedURL: url }),

  // ------------------------------

  setSelectedUrlTab: (tab: string) => set({ selectedUrlTab: tab }),

  // ------------------------------

  setSelectedUrlViewTab: (tab: string) => set({ selectedUrlViewTab: tab }),

  // ------------------------------

  setSelectedIssueTab: (tab) => set({ selectedIssueTab: tab }),

  // ------------------------------

  setSelectedIssueBatch: (batch) => set({ selectedIssueBatch: batch }),

  // ------------------------------

  setSelectedIssueDetailView: (format: string) =>
    set({ selectedIssueDetailView: format }),

  // ------------------------------

  setSelectedResponseTime: (time) => set({ selectedResponseTime: time }),

  // ------------------------------

  setUrlSearchQuery: (query) => set({ urlSearchQuery: query }),

  // ------------------------------

  reset: () => set(initialStates),
}));
