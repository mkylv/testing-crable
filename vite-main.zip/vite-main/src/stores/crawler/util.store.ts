import { create } from "zustand";

type CrawlerUtilStatus =
  | "not-started"
  | "in-progress"
  | "done"
  | "paused"
  | "stopping";

interface CrawlerUtilStore {
  socket: WebSocket | null;
  status: CrawlerUtilStatus;

  setSocket: (socket: WebSocket) => void;
  setStatus: (status: CrawlerUtilStatus) => void;
}

export const useCrawlerUtilStore = create<CrawlerUtilStore>((set) => ({
  socket: null,
  status: "not-started",

  setSocket: (socket: WebSocket) => set({ socket }),
  setStatus: (status: CrawlerUtilStatus) => set({ status }),
}));
