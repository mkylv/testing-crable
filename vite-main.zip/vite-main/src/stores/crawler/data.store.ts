import { create } from "zustand";

interface CrawlerDataStore {
  crawlData: any[];
  appendCrawlData: (data: any) => void;
  setCrawlData: (data: any) => void;

  batchedCrawlData: any[];
  setBatchedCrawlData: (data: any[]) => void;

  rawIssues: any[];
  setRawIssues: (data: any[]) => void;

  issues: any[];
  setIssues: (data: any[]) => void;

  reset: () => void;
}

const initialState = {
  crawlData: [],

  batchedCrawlData: [],

  rawIssues: [],

  issues: [],
};

export const useCrawlerDataStore = create<CrawlerDataStore>((set) => ({
  ...initialState,

  appendCrawlData: (data: any) =>
    set((state) => ({
      crawlData: [...state.crawlData, data],
    })),
  setCrawlData: (data: any[]) => set({ crawlData: data }),

  setBatchedCrawlData: (data: any[]) => set({ batchedCrawlData: data }),

  setRawIssues: (data: any[]) => set({ rawIssues: data }),

  setIssues: (data: any[]) => set({ issues: data }),

  reset: () => set(initialState),
}));
