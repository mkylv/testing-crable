import { cn } from "@/lib/utils";
import crab from "./crab.svg";

export const Crab = ({ className }: { className?: string }) => (
  <img alt="Crab" src={crab} className={cn("w-6 h-6", className)} />
);
