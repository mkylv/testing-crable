import { Toaster } from "@/components/ui/toaster";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { RouterProvider } from "react-router-dom";
import { router } from "./router";
import CheckUnload from "@/components/common/unload-check";
import { ThemeProvider } from "@/lib/theme";

const client = new QueryClient();

export default function AppProvider() {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      disableTransitionOnChange
    >
      <QueryClientProvider client={client}>
        <RouterProvider router={router} />
        <Toaster />
        <CheckUnload />
      </QueryClientProvider>
    </ThemeProvider>
  );
}
