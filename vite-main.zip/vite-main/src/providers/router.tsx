import { createBrowserRouter, Navigate, Outlet } from "react-router-dom";
import {
  WithAuth,
  NoAuthRequired,
  WithVerification,
} from "@/components/layouts/auth";
import LoginPage from "@/pages/auth/login/form";
import RegisterPage from "@/pages/auth/register/form";
import ForgotPasswordPage from "@/pages/auth/forgot-password/form";
import CrawlerPage from "@/pages/dashboard/crawler";
import DashboardLayout from "@/components/layouts/dashboard";
import SettingsPage from "@/pages/dashboard/settings";
import CreateProjectPage from "@/pages/project";
import GoogleAuthCallbackPage from "@/pages/auth/login/google/callback";
import SuspendedPage from "@/pages/suspended";

export const router = createBrowserRouter([
  {
    path: "/",
    children: [
      {
        element: <WithAuth />,
        children: [
          { path: "create-project", element: <CreateProjectPage /> },
          {
            path: "dashboard",
            element: <DashboardLayout />,
            children: [
              {
                path: "",
                element: <WithVerification />,
                children: [
                  { path: "", element: <Navigate to="crawler" /> },
                  {
                    path: "crawler",
                    element: <CrawlerPage />,
                  },
                ],
              },
              {
                path: "settings",
                element: <SettingsPage />,
              },
            ],
          },
        ],
      },
      {
        path: "/",
        element: <NoAuthRequired />,
        children: [
          {
            path: "login",
            element: (
              <>
                <LoginPage />
                <Outlet />
              </>
            ),
            children: [
              {
                path: "google",
                children: [
                  {
                    path: "callback",
                    element: <GoogleAuthCallbackPage />,
                  },
                ],
              },
            ],
          },
          {
            path: "register",
            element: <RegisterPage />,
          },
          {
            path: "forgot-password",
            element: <ForgotPasswordPage />,
          },
        ],
      },
      {
        path: "suspended",
        element: <SuspendedPage />,
      },
    ],
  },
]);
